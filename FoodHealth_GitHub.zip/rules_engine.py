# ai/rules_engine.py
"""
================================================================
   Rule-Based AI Engine  —  محرك الذكاء الاصطناعي القائم على القواعد
================================================================

هذا هو المكوّن الرئيسي للذكاء الاصطناعي في المشروع.

النوع: Rule-Based AI (Expert System بسيط)
وليس: Machine Learning Model.

لماذا Rule-Based وليس ML في هذا المكوّن؟
    لأن القرار الصحي هنا يعتمد على معايير غذائية معروفة ومحددة
    (نسب السكر، الصوديوم، الدهون...) ولا يحتاج "تعلّمًا" من بيانات
    تاريخية لاستخراج نمط غير معروف. هذا هو الاستخدام الصحيح
    والصادق أكاديميًا لـ Rule-Based AI مقابل Machine Learning.
    (نموذج ML تجريبي إضافي موجود في ai/model.py كمكوّن منفصل ومصرّح عنه).

Algorithm Location:
    File     -> ai/rules_engine.py
    Function -> evaluate_product()
    Called from -> routes/evaluation.py  (POST /evaluate/<product_id>)

المدخل (Input):
    - القيم الغذائية بعد التطبيع (per 100g) من preprocessing.normalize_per_100()
    - قائمة المكونات المصنّفة
    - الحالة الصحية المختارة (health_condition) — اختياري

المعالجة (Processing):
    - تطبيق مجموعة قواعد IF-THEN مستقلة
    - كل قاعدة مفعّلة تضيف نقاط خطر (Risk Points) من config.RISK_POINTS
    - تُجمع النقاط في Risk Score إجمالي

المخرج (Output):
    - Risk Score رقمي
    - Risk Level: SAFE / CAUTION / UNSAFE
    - قائمة القواعد المفعّلة (Detected Risks) مع سبب كل واحدة
    - توصية نصية مرتبطة بالأسباب
"""

import json
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config


def _rule_sugar(n):
    if n["sugar"] > config.THRESHOLDS["sugar_high"]:
        return "sugar_high", "نسبة السكر مرتفعة جدًا (> {:.1f}غ/100غ)".format(config.THRESHOLDS["sugar_high"])
    if n["sugar"] > config.THRESHOLDS["sugar_medium"]:
        return "sugar_medium", "نسبة السكر متوسطة الارتفاع"
    return None


def _rule_sodium(n):
    if n["sodium"] > config.THRESHOLDS["sodium_high"]:
        return "sodium_high", "نسبة الصوديوم مرتفعة جدًا (> {:.0f}ملغم/100غ)".format(config.THRESHOLDS["sodium_high"])
    if n["sodium"] > config.THRESHOLDS["sodium_medium"]:
        return "sodium_medium", "نسبة الصوديوم متوسطة الارتفاع"
    return None


def _rule_saturated_fat(n):
    if n["saturated_fat"] > config.THRESHOLDS["saturated_fat_high"]:
        return "saturated_fat_high", "الدهون المشبعة مرتفعة جدًا (> {:.1f}غ/100غ)".format(config.THRESHOLDS["saturated_fat_high"])
    if n["saturated_fat"] > config.THRESHOLDS["saturated_fat_medium"]:
        return "saturated_fat_medium", "الدهون المشبعة متوسطة الارتفاع"
    return None


def _rule_total_fat(n):
    if n["total_fat"] > config.THRESHOLDS["total_fat_high"]:
        return "total_fat_high", "إجمالي الدهون مرتفع (> {:.1f}غ/100غ)".format(config.THRESHOLDS["total_fat_high"])
    return None


def _rule_fiber(n):
    if n["fiber"] < config.THRESHOLDS["fiber_low"]:
        return "fiber_low", "نسبة الألياف منخفضة (< {:.1f}غ/100غ)".format(config.THRESHOLDS["fiber_low"])
    return None


def _rule_caffeine(n):
    if n["caffeine"] > config.THRESHOLDS["caffeine_high"]:
        return "caffeine_high", "نسبة الكافيين مرتفعة (> {:.0f}ملغم)".format(config.THRESHOLDS["caffeine_high"])
    return None


def _rule_preservatives(n):
    if n["preservatives_count"] >= config.THRESHOLDS["preservatives_high"]:
        return "preservatives_high", "يحتوي على عدد كبير من المواد الحافظة ({} أو أكثر)".format(
            config.THRESHOLDS["preservatives_high"])
    return None


# قواعد إضافية مرتبطة بحالات صحية اختيارية (Health Condition Rules)
# هذه قواعد تعليمية مبسّطة فقط — وليست تشخيصًا طبيًا (انظر Medical Disclaimer)
def _condition_rules(n, health_condition):
    extra = []
    if health_condition == "diabetes":
        if n["sugar"] > config.THRESHOLDS["sugar_medium"]:
            extra.append(("condition_sugar", "قد لا يكون مناسبًا لمرضى السكري بسبب نسبة السكر", 2))
    elif health_condition == "hypertension":
        if n["sodium"] > config.THRESHOLDS["sodium_medium"]:
            extra.append(("condition_sodium", "قد لا يكون مناسبًا لمرضى ضغط الدم بسبب نسبة الصوديوم", 2))
    elif health_condition == "heart_disease":
        if n["saturated_fat"] > config.THRESHOLDS["saturated_fat_medium"]:
            extra.append(("condition_fat", "قد لا يكون مناسبًا لمرضى القلب بسبب الدهون المشبعة", 2))
    return extra


RULE_FUNCTIONS = [
    _rule_sugar, _rule_sodium, _rule_saturated_fat,
    _rule_total_fat, _rule_fiber, _rule_caffeine, _rule_preservatives,
]


def evaluate_product(normalized_nutrition: dict, ingredients: list = None,
                      health_condition: str = "general") -> dict:
    """
    الدالة الرئيسية لمحرك الذكاء الاصطناعي (Rule-Based Classification).

    مثال على قاعدة (كما هو مطلوب أكاديميًا):
        IF Sugar > 22.5
        THEN Increase Risk Score by 3, Add Warning "نسبة السكر مرتفعة"
    """
    detected_risks = []
    score = 0

    for rule_fn in RULE_FUNCTIONS:
        result = rule_fn(normalized_nutrition)
        if result:
            rule_id, message = result
            points = config.RISK_POINTS.get(rule_id, 1)
            score += points
            detected_risks.append({"rule": rule_id, "message": message, "points": points})

    for rule_id, message, points in _condition_rules(normalized_nutrition, health_condition):
        score += points
        detected_risks.append({"rule": rule_id, "message": message, "points": points})

    # فحص المكونات (Ingredient-based rule)
    if ingredients:
        preservative_count = sum(1 for i in ingredients if i.get("type") == "preservative")
        allergen_items = [i["name"] for i in ingredients if i.get("type") == "allergen"]
        if allergen_items:
            detected_risks.append({
                "rule": "allergen_present",
                "message": f"يحتوي على مكونات قد تكون مسببة للحساسية: {', '.join(allergen_items)}",
                "points": 0,  # تحذير فقط، لا يرفع الخطورة تلقائيًا
            })

    # تجميع النتائج -> Classification
    if score <= config.CLASSIFICATION_BOUNDARIES["safe_max"]:
        risk_level = "SAFE"
    elif score <= config.CLASSIFICATION_BOUNDARIES["caution_max"]:
        risk_level = "CAUTION"
    else:
        risk_level = "UNSAFE"

    recommendation = _build_recommendation(risk_level, detected_risks)

    return {
        "score": score,
        "risk_level": risk_level,
        "detected_risks": detected_risks,
        "recommendation": recommendation,
        "detected_risks_json": json.dumps(detected_risks, ensure_ascii=False),
    }


def _build_recommendation(risk_level, detected_risks):
    """يبني توصية نصية مرتبطة مباشرة بأسباب القرار (Explainable AI)."""
    if risk_level == "SAFE":
        base = "المنتج يبدو مناسبًا وفق المعايير الغذائية العامة المستخدمة في هذا النظام."
    elif risk_level == "CAUTION":
        base = "يُنصح بالانتباه عند استهلاك هذا المنتج والاعتدال فيه."
    else:
        base = "يُفضّل تقليل استهلاك هذا المنتج أو تجنبه وفق المعايير المستخدمة."

    if detected_risks:
        reasons = "؛ ".join(r["message"] for r in detected_risks if r["points"] > 0)
        if reasons:
            base += " الأسباب: " + reasons + "."

    base += " (هذا تقييم تعليمي إرشادي وليس بديلاً عن استشارة طبيب أو أخصائي تغذية)."
    return base
