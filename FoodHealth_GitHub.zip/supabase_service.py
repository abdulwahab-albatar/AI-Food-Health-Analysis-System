﻿from supabase import create_client
import config


def get_client():
    """Return Supabase client when configured."""
    if not config.SUPABASE_ENABLED:
        return None

    return create_client(
        config.SUPABASE_URL,
        config.SUPABASE_KEY
    )


def is_available():
    """Check whether Supabase can be reached."""
    try:
        client = get_client()

        if client is None:
            return False

        response = (
            client
            .table("products")
            .select("product_id")
            .limit(1)
            .execute()
        )

        return response.data is not None

    except Exception:
        return False


def get_products():
    """Get all products from Supabase."""
    client = get_client()

    if client is None:
        return []

    response = (
        client
        .table("products")
        .select("*")
        .order("product_id")
        .execute()
    )

    return response.data or []


def get_product_by_id(product_id):
    """Get one product from Supabase by ID."""
    client = get_client()

    if client is None:
        return None

    response = (
        client
        .table("products")
        .select("*")
        .eq("product_id", product_id)
        .limit(1)
        .execute()
    )

    if not response.data:
        return None

    return response.data[0]


def get_product_by_barcode(barcode):
    """Get one product from Supabase by barcode."""
    client = get_client()

    if client is None:
        return None

    response = (
        client
        .table("products")
        .select("*")
        .eq("barcode", str(barcode))
        .limit(1)
        .execute()
    )

    if not response.data:
        return None

    return response.data[0]