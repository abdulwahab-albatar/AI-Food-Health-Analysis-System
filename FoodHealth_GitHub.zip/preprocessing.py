# ai/preprocessing.py
"""
مرحلة Data Preprocessing.

هذا الملف مسؤول فقط عن: التحقق (Validation)، التنظيف (Cleaning)،
معالجة القيم المفقودة، تحويل الأنواع، وتوحيد المكونات.
لا يوجد هنا أي منطق قرار صحي — ذلك من مسؤولية rules_engine.py.

Algorithm Location:
    File     -> ai/preprocessing.py
    Function -> validate_product_input(), clean_ingredients()
    Called from -> routes/products.py (عند إضافة/تعديل منتج)
"""

import re


class ValidationError(Exception):
    """يُرفع عند فشل التحقق من صحة البيانات المدخلة."""
    pass


NUMERIC_FIELDS = [
    "calories", "sugar", "total_fat", "saturated_fat",
    "carbohydrates", "fiber", "protein", "sodium",
    "caffeine", "preservatives_count",
]


def validate_barcode(barcode: str) -> str:
    """
    يتحقق من صحة الباركود:
      - غير فارغ
      - يحتوي على أرقام فقط
      - طول منطقي (8 إلى 14 رقمًا - يغطي EAN-8 إلى EAN-14)
    """
    if barcode is None:
        raise ValidationError("الباركود مطلوب.")
    barcode = barcode.strip()
    if not barcode:
        raise ValidationError("الباركود لا يمكن أن يكون فارغًا.")
    if not barcode.isdigit():
        raise ValidationError("الباركود يجب أن يحتوي على أرقام فقط.")
    if not (8 <= len(barcode) <= 14):
        raise ValidationError("طول الباركود غير منطقي (يجب أن يكون بين 8 و14 رقمًا).")
    return barcode


def _to_float(value, field_name):
    try:
        return float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"القيمة '{field_name}' يجب أن تكون رقمًا.")


def validate_product_input(data: dict) -> dict:
    """
    يتحقق من كامل بيانات المنتج (Structural + Logical Validation) ويعيد
    نسخة نظيفة من البيانات (Numeric Conversion منجزة).

    Logical Validation المطبّقة:
        - القيم الرقمية غير سالبة
        - saturated_fat <= total_fat
        - fiber <= carbohydrates
        - serving_size > 0
    """
    cleaned = {}

    product_name = (data.get("product_name") or "").strip()
    if not product_name:
        raise ValidationError("اسم المنتج مطلوب.")
    cleaned["product_name"] = product_name

    cleaned["barcode"] = validate_barcode(data.get("barcode"))

    cleaned["manufacturer"] = (data.get("manufacturer") or "").strip()
    cleaned["category"] = (data.get("category") or "غير محدد").strip()
    cleaned["unit"] = (data.get("unit") or "g").strip()

    serving_size = _to_float(data.get("serving_size"), "serving_size")
    if serving_size <= 0:
        raise ValidationError("حجم الحصة (Serving Size) يجب أن يكون أكبر من صفر.")
    cleaned["serving_size"] = serving_size

    nutrition = {}
    for field in NUMERIC_FIELDS:
        raw = data.get(field, 0)
        val = _to_float(raw if raw not in (None, "") else 0, field)
        if val < 0:
            raise ValidationError(f"القيمة '{field}' لا يمكن أن تكون سالبة.")
        nutrition[field] = val

    # Logical Validation بين الحقول
    if nutrition["saturated_fat"] > nutrition["total_fat"]:
        raise ValidationError("الدهون المشبعة (Saturated Fat) لا يمكن أن تكون أكبر من إجمالي الدهون (Total Fat).")
    if nutrition["fiber"] > nutrition["carbohydrates"]:
        raise ValidationError("الألياف (Fiber) لا يمكن أن تكون أكبر من الكربوهيدرات (Carbohydrates).")

    nutrition["preservatives_count"] = int(nutrition["preservatives_count"])
    cleaned["nutrition"] = nutrition

    cleaned["ingredients"] = clean_ingredients(data.get("ingredients", ""))

    return cleaned


def clean_ingredients(raw_text) -> list:
    """
    تنظيف نص المكونات:
      1. إذا وصلت كقائمة جاهزة (list) تُرجَع كما هي بعد تنظيف بسيط.
      2. إذا وصلت كنص، يتم:
         - توحيد الفاصلة العربية "،" إلى "," الإنجليزية
         - تقسيم النص إلى عناصر
         - إزالة المسافات الزائدة
         - إزالة العناصر الفارغة
         - تصنيف كل مكوّن (natural / preservative / additive) بشكل مبسّط
    """
    if isinstance(raw_text, list):
        items = raw_text
    else:
        if not raw_text:
            return []
        text = raw_text.replace("،", ",")
        items = [i.strip() for i in text.split(",")]

    items = [i for i in items if i]  # إزالة الفارغة
    # إزالة التكرار مع الحفاظ على الترتيب
    seen = set()
    unique_items = []
    for i in items:
        key = i.lower()
        if key not in seen:
            seen.add(key)
            unique_items.append(i)

    result = []
    for name in unique_items:
        result.append({"name": name, "type": classify_ingredient(name)})
    return result


PRESERVATIVE_KEYWORDS = [
    "بنزوات", "نتريت", "نترات", "سوربات", "كبريتيت", "preservative",
    "benzoate", "nitrite", "nitrate", "sorbate", "sulphite", "sulfite", "bha", "bht",
]
ARTIFICIAL_KEYWORDS = [
    "صناعي", "artificial", "نكهة صناعية", "ملون صناعي", "aspartame", "أسبارتام",
]
ALLERGEN_KEYWORDS = [
    "فول سوداني", "peanut", "حليب", "milk", "بيض", "egg", "جلوتين", "gluten", "مكسرات", "nuts",
]


def classify_ingredient(name: str) -> str:
    """تصنيف مبسّط للمكوّن اعتمادًا على كلمات مفتاحية (Rule-Based Text Classification)."""
    lowered = name.lower()
    for kw in PRESERVATIVE_KEYWORDS:
        if kw in lowered:
            return "preservative"
    for kw in ARTIFICIAL_KEYWORDS:
        if kw in lowered:
            return "artificial"
    for kw in ALLERGEN_KEYWORDS:
        if kw in lowered:
            return "allergen"
    return "natural"


def normalize_per_100(nutrition: dict, serving_size: float, unit: str) -> dict:
    """
    يوحّد القيم الغذائية إلى 'لكل 100 غرام/مل' حتى تكون قابلة للمقارنة
    ومناسبة لتطبيق العتبات (Thresholds) الموجودة في config.py، والتي
    مصدرها معايير عامة تُحسب لكل 100 غرام.

    ملاحظة: يُفترض أن القيم المدخلة هي "لكل حصة" (Per Serving)، لذلك
    نحوّلها إلى "لكل 100 غرام/مل" عبر قاعدة التناسب البسيطة.
    """
    if serving_size <= 0:
        return nutrition
    factor = 100.0 / serving_size
    normalized = {}
    for key, value in nutrition.items():
        if key == "preservatives_count":
            normalized[key] = value  # عدد وليس كمية، لا يُطبَّع
        else:
            normalized[key] = round(value * factor, 3)
    return normalized
