

import sys
import threading
import subprocess
import re
import time

from flask import Flask, render_template, jsonify

import config
from database import db_helper

from routes.sync import sync_bp
from routes.products import products_bp
from routes.evaluation import evaluation_bp
from routes.api import api_bp

from services.sync_service import sync_on_startup


# =========================================================
# Cloudflare Tunnel
# =========================================================

CLOUDFLARED_PATH = (
    r"C:\Program Files (x86)\cloudflared\cloudflared.exe"
)

cloudflare_process = None
cloudflare_url = None
cloudflare_lock = threading.Lock()


def start_cloudflare():
    """
    Start Cloudflare Quick Tunnel automatically.

    Cloudflare runs in the background without opening
    a console window.

    The detected public URL is stored in cloudflare_url
    and can be requested by the FoodHealth interface.
    """

    global cloudflare_process
    global cloudflare_url

    try:
        # Give Flask time to start
        time.sleep(2)

        cloudflare_process = subprocess.Popen(
            [
                CLOUDFLARED_PATH,
                "tunnel",
                "--url",
                f"http://127.0.0.1:{config.PORT}",
                "--loglevel",
                "info",
                "--no-autoupdate",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )

        # Read Cloudflare output
        for line in cloudflare_process.stdout:

            match = re.search(
                r"https://[a-zA-Z0-9.-]+\.trycloudflare\.com",
                line
            )

            if match:

                detected_url = match.group(0)

                with cloudflare_lock:
                    cloudflare_url = detected_url

                print()
                print("=" * 60)
                print("Public URL:")
                print(cloudflare_url)
                print("=" * 60)
                print()

                # Do NOT stop Cloudflare.
                # Continue reading its output silently.

    except FileNotFoundError:

        print()
        print("Cloudflare Error:")
        print("cloudflared.exe was not found at:")
        print(CLOUDFLARED_PATH)
        print()

    except Exception as exc:

        print()
        print(f"Cloudflare Tunnel Error: {exc}")
        print()


# =========================================================
# Create Flask Application
# =========================================================

def create_app():

    app = Flask(__name__)

    app.secret_key = config.SECRET_KEY

    # ---------------------------------------------------------
    # Debug
    # ---------------------------------------------------------

    app.config["DEBUG"] = False

    # ---------------------------------------------------------
    # Initialize local database
    # ---------------------------------------------------------

    db_helper.init_db()

    # ---------------------------------------------------------
    # Register routes
    # ---------------------------------------------------------

    app.register_blueprint(sync_bp)
    app.register_blueprint(products_bp)
    app.register_blueprint(evaluation_bp)
    app.register_blueprint(api_bp)

    # ---------------------------------------------------------
    # Home
    # ---------------------------------------------------------

    @app.route("/")
    def home():

        stats = db_helper.get_statistics()

        return render_template(
            "index.html",
            stats=stats
        )

    # ---------------------------------------------------------
    # Cloudflare URL API
    # ---------------------------------------------------------

    @app.route("/cloudflare-url")
    def get_cloudflare_url():

        with cloudflare_lock:
            current_url = cloudflare_url

        return jsonify({
            "ready": current_url is not None,
            "url": current_url
        })

    # ---------------------------------------------------------
    # 404
    # ---------------------------------------------------------

    @app.errorhandler(404)
    def not_found(e):

        return render_template(
            "base.html",
            content_404=True
        ), 404

    return app


# =========================================================
# Application Instance
# =========================================================

app = create_app()


# =========================================================
# Startup Synchronization
# =========================================================

def run_startup_sync():

    """
    Run synchronization in a background thread.
    """

    try:

        sync_on_startup()

    except Exception as exc:

        print(
            f"FoodHealth Sync Error: {exc}"
        )

        print(
            "Application will continue "
            "using local database."
        )


# =========================================================
# Start Background Services
# =========================================================

def start_background_services():

    # ---------------------------------------------------------
    # Automatic synchronization
    # ---------------------------------------------------------

    if getattr(
        config,
        "SYNC_ENABLED",
        True
    ):

        sync_thread = threading.Thread(
            target=run_startup_sync,
            daemon=True
        )

        sync_thread.start()

    # ---------------------------------------------------------
    # Cloudflare Tunnel
    # ---------------------------------------------------------

    cloudflare_thread = threading.Thread(
        target=start_cloudflare,
        daemon=True
    )

    cloudflare_thread.start()


# =========================================================
# Web Mode
# =========================================================

def run_web():

    print()
    print("=" * 60)
    print("FoodHealth")
    print("=" * 60)

    print(
        f"Database: "
        f"{config.DATABASE_PATH}"
    )

    print(
        f"Local application: "
        f"http://127.0.0.1:{config.PORT}"
    )

    print("=" * 60)
    print()

    # Start background services
    start_background_services()

    # ---------------------------------------------------------
    # Start Flask
    # ---------------------------------------------------------

    app.run(
        host="127.0.0.1",
        port=config.PORT,
        debug=False,
        use_reloader=False
    )


# =========================================================
# Desktop Mode
# =========================================================

def run_desktop():

    """
    Desktop application using pywebview.

    Flask runs locally on 127.0.0.1.

    No external browser is opened.

    Cloudflare runs silently in the background.
    """

    try:

        import webview

        # -----------------------------------------------------
        # Start Flask server
        # -----------------------------------------------------

        server_thread = threading.Thread(
            target=lambda: app.run(
                host="127.0.0.1",
                port=config.PORT,
                debug=False,
                use_reloader=False
            ),
            daemon=True
        )

        server_thread.start()

        # -----------------------------------------------------
        # Give Flask time to start
        # -----------------------------------------------------

        time.sleep(1.5)

        # -----------------------------------------------------
        # Start background services
        # -----------------------------------------------------

        start_background_services()

        # -----------------------------------------------------
        # Open ONLY FoodHealth desktop window
        # -----------------------------------------------------

        window = webview.create_window(
            "FoodHealth",
            f"http://127.0.0.1:{config.PORT}",
            width=1200,
            height=800,
            resizable=True
        )

        # -----------------------------------------------------
        # Start pywebview
        # -----------------------------------------------------

        webview.start()

    except ImportError:

        print(
            "pywebview is not installed."
        )

        print(
            "Run:"
        )

        print(
            r"C:\Users\TSS\.conda\envs\foodhealth\python.exe "
            "-m pip install pywebview"
        )

        print(
            "Starting normal web mode..."
        )

        run_web()

    except Exception as exc:

        print()
        print(
            f"Desktop application error: {exc}"
        )
        print()

        raise


# =========================================================
# Main
# =========================================================

if __name__ == "__main__":

    if "--desktop" in sys.argv:

        run_desktop()

    else:

        run_web()