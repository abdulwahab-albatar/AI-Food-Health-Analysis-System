# services/food_api.py
"""
خدمة الاتصال بمصدر بيانات غذائية خارجي (External API).

مسؤولية هذا الملف فقط: جلب بيانات منتج عبر الإنترنت باستخدام الباركود.
هذا الملف منفصل تمامًا عن database/db_helper.py (API Layer != Database Layer)
وواجهة المستخدم (HTML) لا تتصل بهذا الـ API مباشرة أبدًا؛ الاتصال دائمًا
عبر Backend (routes/api.py).

المصدر المستخدم: Open Food Facts (خدمة عامة مجانية لا تتطلب مفتاح API).
    https://world.openfoodfacts.org/api/v2/product/<barcode>.json

معالجة الحالات المطلوبة أكاديميًا:
    - Product Found
    - Product Not Found
    - API Error / Timeout
    - Internet Failure
    - Invalid Response
"""

import requests

TIMEOUT_SECONDS = 5
API_URL_TEMPLATE = "https://world.openfoodfacts.org/api/v2/product/{barcode}.json"


def fetch_product_by_barcode(barcode: str) -> dict:
    """
    يحاول جلب بيانات منتج من Open Food Facts عبر الباركود.

    Returns:
        dict بأحد الشكلين:
        {"status": "found", "data": {...}}
        {"status": "not_found"}
        {"status": "error", "message": "..."}
    """
    try:
        response = requests.get(API_URL_TEMPLATE.format(barcode=barcode), timeout=TIMEOUT_SECONDS)
    except requests.exceptions.Timeout:
        return {"status": "error", "message": "انتهت مهلة الاتصال بمصدر البيانات الخارجي."}
    except requests.exceptions.ConnectionError:
        return {"status": "error", "message": "تعذّر الاتصال بالإنترنت. تحقق من الشبكة."}
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": f"خطأ في الاتصال بالـ API: {e}"}

    if response.status_code != 200:
        return {"status": "error", "message": f"استجابة غير متوقعة من الخادم (HTTP {response.status_code})."}

    try:
        payload = response.json()
    except ValueError:
        return {"status": "error", "message": "استجابة API غير صالحة (ليست JSON)."}

    if payload.get("status") != 1 or "product" not in payload:
        return {"status": "not_found"}

    product = payload["product"]
    nutriments = product.get("nutriments", {})

    try:
        mapped = {
            "product_name": product.get("product_name") or "منتج بدون اسم",
            "manufacturer": product.get("brands", ""),
            "category": (product.get("categories", "").split(",")[0] if product.get("categories") else ""),
            "serving_size": 100.0,   # Open Food Facts يعطي القيم غالبًا لكل 100غ افتراضيًا
            "unit": "g",
            "nutrition": {
                "calories": nutriments.get("energy-kcal_100g", 0) or 0,
                "sugar": nutriments.get("sugars_100g", 0) or 0,
                "total_fat": nutriments.get("fat_100g", 0) or 0,
                "saturated_fat": nutriments.get("saturated-fat_100g", 0) or 0,
                "carbohydrates": nutriments.get("carbohydrates_100g", 0) or 0,
                "fiber": nutriments.get("fiber_100g", 0) or 0,
                "protein": nutriments.get("proteins_100g", 0) or 0,
                "sodium": (nutriments.get("sodium_100g", 0) or 0) * 1000,  # تحويل من غرام إلى ملغم
                "caffeine": 0,
                "preservatives_count": 0,
            },
            "ingredients": product.get("ingredients_text", ""),
        }
        return {"status": "found", "data": mapped}
    except Exception as e:
        return {"status": "error", "message": f"تعذّر تفسير بيانات المنتج القادمة من API: {e}"}
