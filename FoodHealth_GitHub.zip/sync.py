# routes/sync.py

from flask import Blueprint, jsonify, request

from services.sync_service import export_products, import_products


sync_bp = Blueprint(
    "sync",
    __name__,
    url_prefix="/api/sync"
)


@sync_bp.route("/status", methods=["GET"])
def sync_status():

    data = export_products()

    return jsonify({
        "success": True,
        "service": "FoodHealth Sync",
        "version": data.get("version", 1),
        "product_count": data.get("product_count", 0),
        "generated_at": data.get("generated_at")
    })


@sync_bp.route("/export", methods=["GET"])
def sync_export():

    data = export_products()

    return jsonify(data)


@sync_bp.route("/import", methods=["POST"])
def sync_import():

    data = request.get_json(silent=True)

    if not data:
        return jsonify({
            "success": False,
            "error": "No JSON data received"
        }), 400

    try:

        result = import_products(data)

        return jsonify(result)

    except Exception as exc:

        return jsonify({
            "success": False,
            "error": str(exc)
        }), 500