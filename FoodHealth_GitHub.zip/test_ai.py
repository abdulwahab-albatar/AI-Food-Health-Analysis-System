# tests/test_ai.py
"""
اختبارات محرك الذكاء الاصطناعي (Rule-Based AI).
تشمل: Normal Product, High Sugar, High Sodium, High Fat, Boundary Values.
"""

import os
import sys
import unittest

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from ai.rules_engine import evaluate_product


def base_nutrition(**overrides):
    n = {
        "sugar": 0, "sodium": 0, "saturated_fat": 0, "total_fat": 0,
        "fiber": 6, "protein": 0, "carbohydrates": 0, "calories": 0,
        "caffeine": 0, "preservatives_count": 0,
    }
    n.update(overrides)
    return n


class TestRulesEngine(unittest.TestCase):
    def test_normal_product_is_safe(self):
        result = evaluate_product(base_nutrition())
        self.assertEqual(result["risk_level"], "SAFE")
        self.assertEqual(result["score"], 0)

    def test_high_sugar_increases_risk(self):
        result = evaluate_product(base_nutrition(sugar=30))
        self.assertIn(("sugar_high"), [r["rule"] for r in result["detected_risks"]])
        self.assertNotEqual(result["risk_level"], "SAFE")

    def test_high_sodium_increases_risk(self):
        result = evaluate_product(base_nutrition(sodium=700))
        self.assertIn("sodium_high", [r["rule"] for r in result["detected_risks"]])

    def test_high_saturated_fat(self):
        result = evaluate_product(base_nutrition(saturated_fat=8, total_fat=10))
        self.assertIn("saturated_fat_high", [r["rule"] for r in result["detected_risks"]])

    def test_multiple_risks_lead_to_unsafe(self):
        result = evaluate_product(base_nutrition(sugar=35, sodium=800, saturated_fat=10, total_fat=20))
        self.assertEqual(result["risk_level"], "UNSAFE")

    def test_boundary_sugar_threshold(self):
        """Boundary Testing: X-1, X, X+1 حول عتبة السكر المرتفع."""
        threshold = config.THRESHOLDS["sugar_high"]

        below = evaluate_product(base_nutrition(sugar=threshold - 1))
        at = evaluate_product(base_nutrition(sugar=threshold))
        above = evaluate_product(base_nutrition(sugar=threshold + 1))

        below_rules = [r["rule"] for r in below["detected_risks"]]
        at_rules = [r["rule"] for r in at["detected_risks"]]
        above_rules = [r["rule"] for r in above["detected_risks"]]

        self.assertNotIn("sugar_high", below_rules)
        self.assertNotIn("sugar_high", at_rules)  # القاعدة تستخدم "أكبر من" وليس "أكبر أو يساوي"
        self.assertIn("sugar_high", above_rules)

    def test_health_condition_diabetes_adds_extra_risk(self):
        general = evaluate_product(base_nutrition(sugar=10), health_condition="general")
        diabetes = evaluate_product(base_nutrition(sugar=10), health_condition="diabetes")
        self.assertGreaterEqual(diabetes["score"], general["score"])

    def test_recommendation_is_not_empty(self):
        result = evaluate_product(base_nutrition(sugar=30))
        self.assertTrue(len(result["recommendation"]) > 0)
        self.assertIn("تعليمي", result["recommendation"])


if __name__ == "__main__":
    unittest.main()
