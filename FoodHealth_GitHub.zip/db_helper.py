# database/db_helper.py
"""
طبقة الوصول لقاعدة البيانات (Database Access Layer).

هذا هو المكان الوحيد في المشروع الذي يُسمح فيه بكتابة SQL.
لا يوجد SQL في أي مكان آخر (لا في HTML ولا في routes) — طبقًا لمبدأ
فصل المسؤوليات (Separation of Concerns).

قاعدة البيانات: SQLite (food_health.db)

الجداول:
    products      -> بيانات المنتج الأساسية
    nutrition     -> القيم الغذائية (علاقة 1-to-1 مع products)
    ingredients   -> المكونات (علاقة 1-to-Many مع products)
    evaluations   -> نتائج تقييم الذكاء الاصطناعي (علاقة 1-to-Many مع products)
"""

import sqlite3
import os
import shutil
from datetime import datetime

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS products (
    product_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    barcode         TEXT UNIQUE NOT NULL,
    product_name    TEXT NOT NULL,
    manufacturer    TEXT,
    category        TEXT,
    serving_size    REAL NOT NULL,
    unit            TEXT NOT NULL DEFAULT 'g',
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS nutrition (
    nutrition_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id           INTEGER NOT NULL,
    calories              REAL NOT NULL DEFAULT 0,
    sugar                 REAL NOT NULL DEFAULT 0,
    total_fat             REAL NOT NULL DEFAULT 0,
    saturated_fat         REAL NOT NULL DEFAULT 0,
    carbohydrates         REAL NOT NULL DEFAULT 0,
    fiber                 REAL NOT NULL DEFAULT 0,
    protein                REAL NOT NULL DEFAULT 0,
    sodium                 REAL NOT NULL DEFAULT 0,
    caffeine                REAL NOT NULL DEFAULT 0,
    preservatives_count    INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES products (product_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ingredients (
    ingredient_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id         INTEGER NOT NULL,
    ingredient_name    TEXT NOT NULL,
    ingredient_type     TEXT DEFAULT 'natural',
    FOREIGN KEY (product_id) REFERENCES products (product_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS evaluations (
    evaluation_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id          INTEGER NOT NULL,
    health_condition     TEXT DEFAULT 'general',
    score                 REAL NOT NULL,
    risk_level             TEXT NOT NULL,
    recommendation          TEXT,
    detected_risks_json      TEXT,
    evaluation_date            TEXT NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products (product_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_products_barcode ON products (barcode);
CREATE INDEX IF NOT EXISTS idx_nutrition_product ON nutrition (product_id);
CREATE INDEX IF NOT EXISTS idx_ingredients_product ON ingredients (product_id);
CREATE INDEX IF NOT EXISTS idx_evaluations_product ON evaluations (product_id);
"""


def get_connection():
    """يفتح اتصالًا جديدًا بقاعدة البيانات مع تفعيل Foreign Keys."""
    os.makedirs(os.path.dirname(config.DATABASE_PATH), exist_ok=True)
    conn = sqlite3.connect(config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """ينشئ الجداول إذا لم تكن موجودة. يُستدعى عند بدء التطبيق."""
    conn = get_connection()
    try:
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------------
def create_product(barcode, product_name, manufacturer, category,
                    serving_size, unit, nutrition: dict, ingredients: list):
    """يضيف منتجًا جديدًا كاملًا (Product + Nutrition + Ingredients) في عملية واحدة (Transaction)."""
    conn = get_connection()
    now = datetime.now().isoformat(timespec="seconds")
    try:
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO products
               (barcode, product_name, manufacturer, category, serving_size, unit, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (barcode, product_name, manufacturer, category, serving_size, unit, now, now),
        )
        product_id = cur.lastrowid

        cur.execute(
            """INSERT INTO nutrition
               (product_id, calories, sugar, total_fat, saturated_fat, carbohydrates,
                fiber, protein, sodium, caffeine, preservatives_count)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                product_id,
                nutrition.get("calories", 0),
                nutrition.get("sugar", 0),
                nutrition.get("total_fat", 0),
                nutrition.get("saturated_fat", 0),
                nutrition.get("carbohydrates", 0),
                nutrition.get("fiber", 0),
                nutrition.get("protein", 0),
                nutrition.get("sodium", 0),
                nutrition.get("caffeine", 0),
                nutrition.get("preservatives_count", 0),
            ),
        )

        for ing in ingredients:
            cur.execute(
                "INSERT INTO ingredients (product_id, ingredient_name, ingredient_type) VALUES (?, ?, ?)",
                (product_id, ing["name"], ing.get("type", "natural")),
            )

        conn.commit()
        return product_id
    except sqlite3.IntegrityError as e:
        conn.rollback()
        raise ValueError(f"لا يمكن إضافة المنتج: Barcode مكرر أو بيانات غير صحيحة ({e})")
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# READ
# ---------------------------------------------------------------------------
def get_product_by_id(product_id):
    conn = get_connection()
    try:
        product = conn.execute(
            "SELECT * FROM products WHERE product_id = ?", (product_id,)
        ).fetchone()
        if not product:
            return None
        nutrition = conn.execute(
            "SELECT * FROM nutrition WHERE product_id = ?", (product_id,)
        ).fetchone()
        ingredients = conn.execute(
            "SELECT * FROM ingredients WHERE product_id = ?", (product_id,)
        ).fetchall()
        return {
            "product": dict(product),
            "nutrition": dict(nutrition) if nutrition else {},
            "ingredients": [dict(i) for i in ingredients],
        }
    finally:
        conn.close()


def get_product_by_barcode(barcode):
    conn = get_connection()
    try:
        row = conn.execute("SELECT product_id FROM products WHERE barcode = ?", (barcode,)).fetchone()
        conn.close()
        return get_product_by_id(row["product_id"]) if row else None
    finally:
        pass


def list_products(search_term=None, limit=200):
    conn = get_connection()
    try:
        if search_term:
            like = f"%{search_term}%"
            rows = conn.execute(
                """SELECT * FROM products
                   WHERE product_name LIKE ? OR barcode LIKE ? OR manufacturer LIKE ?
                   ORDER BY created_at DESC LIMIT ?""",
                (like, like, like, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM products ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# UPDATE
# ---------------------------------------------------------------------------
def update_product(product_id, product_name, manufacturer, category,
                    serving_size, unit, nutrition: dict, ingredients: list):
    conn = get_connection()
    now = datetime.now().isoformat(timespec="seconds")
    try:
        cur = conn.cursor()
        cur.execute(
            """UPDATE products SET product_name=?, manufacturer=?, category=?,
               serving_size=?, unit=?, updated_at=? WHERE product_id=?""",
            (product_name, manufacturer, category, serving_size, unit, now, product_id),
        )
        cur.execute(
            """UPDATE nutrition SET calories=?, sugar=?, total_fat=?, saturated_fat=?,
               carbohydrates=?, fiber=?, protein=?, sodium=?, caffeine=?, preservatives_count=?
               WHERE product_id=?""",
            (
                nutrition.get("calories", 0), nutrition.get("sugar", 0),
                nutrition.get("total_fat", 0), nutrition.get("saturated_fat", 0),
                nutrition.get("carbohydrates", 0), nutrition.get("fiber", 0),
                nutrition.get("protein", 0), nutrition.get("sodium", 0),
                nutrition.get("caffeine", 0), nutrition.get("preservatives_count", 0),
                product_id,
            ),
        )
        cur.execute("DELETE FROM ingredients WHERE product_id=?", (product_id,))
        for ing in ingredients:
            cur.execute(
                "INSERT INTO ingredients (product_id, ingredient_name, ingredient_type) VALUES (?, ?, ?)",
                (product_id, ing["name"], ing.get("type", "natural")),
            )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# DELETE
# ---------------------------------------------------------------------------
def delete_product(product_id):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM products WHERE product_id = ?", (product_id,))
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# EVALUATIONS
# ---------------------------------------------------------------------------
def save_evaluation(product_id, health_condition, score, risk_level, recommendation, detected_risks_json):
    conn = get_connection()
    now = datetime.now().isoformat(timespec="seconds")
    try:
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO evaluations
               (product_id, health_condition, score, risk_level, recommendation, detected_risks_json, evaluation_date)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (product_id, health_condition, score, risk_level, recommendation, detected_risks_json, now),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_evaluations_for_product(product_id):
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM evaluations WHERE product_id = ? ORDER BY evaluation_date DESC", (product_id,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# DASHBOARD / STATISTICS
# ---------------------------------------------------------------------------
def get_statistics():
    conn = get_connection()
    try:
        total_products = conn.execute("SELECT COUNT(*) c FROM products").fetchone()["c"]

        # آخر تقييم لكل منتج فقط (لتفادي تكرار العد إن قُيّم المنتج أكثر من مرة)
        latest_eval_rows = conn.execute("""
            SELECT e.risk_level FROM evaluations e
            INNER JOIN (
                SELECT product_id, MAX(evaluation_date) AS max_date
                FROM evaluations GROUP BY product_id
            ) latest
            ON e.product_id = latest.product_id AND e.evaluation_date = latest.max_date
        """).fetchall()

        risk_counts = {"SAFE": 0, "CAUTION": 0, "UNSAFE": 0}
        for r in latest_eval_rows:
            risk_counts[r["risk_level"]] = risk_counts.get(r["risk_level"], 0) + 1

        evaluated_count = len(latest_eval_rows)

        avg_row = conn.execute(
            "SELECT AVG(calories) ac, AVG(sugar) asg, AVG(sodium) asd, AVG(total_fat) af FROM nutrition"
        ).fetchone()

        return {
            "total_products": total_products,
            "evaluated_products": evaluated_count,
            "safe_count": risk_counts.get("SAFE", 0),
            "caution_count": risk_counts.get("CAUTION", 0),
            "unsafe_count": risk_counts.get("UNSAFE", 0),
            "avg_calories": round(avg_row["ac"] or 0, 1),
            "avg_sugar": round(avg_row["asg"] or 0, 1),
            "avg_sodium": round(avg_row["asd"] or 0, 1),
            "avg_fat": round(avg_row["af"] or 0, 1),
        }
    finally:
        conn.close()


def get_db_analysis():
    """معلومات وصفية عن قاعدة البيانات نفسها (للإجابة على سؤال 'حلل قاعدة بياناتك')."""
    conn = get_connection()
    try:
        tables = [r["name"] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchall()]
        analysis = {"tables": {}, "table_count": len(tables)}
        total_records = 0
        for t in tables:
            cols = conn.execute(f"PRAGMA table_info({t})").fetchall()
            count = conn.execute(f"SELECT COUNT(*) c FROM {t}").fetchone()["c"]
            total_records += count
            analysis["tables"][t] = {
                "columns": [{"name": c["name"], "type": c["type"], "pk": bool(c["pk"])} for c in cols],
                "record_count": count,
            }
        analysis["total_records"] = total_records
        db_size_bytes = os.path.getsize(config.DATABASE_PATH) if os.path.exists(config.DATABASE_PATH) else 0
        analysis["db_size_kb"] = round(db_size_bytes / 1024, 2)
        return analysis
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# BACKUP
# ---------------------------------------------------------------------------
def backup_database():
    os.makedirs(config.BACKUP_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(config.BACKUP_DIR, f"food_health_backup_{timestamp}.db")
    shutil.copy2(config.DATABASE_PATH, backup_path)
    return backup_path
