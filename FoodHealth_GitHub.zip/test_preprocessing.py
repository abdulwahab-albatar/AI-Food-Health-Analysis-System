# tests/test_preprocessing.py
"""اختبارات Data Preprocessing: Missing Data, Invalid Data, Negative Values, Wrong Units."""

import os
import sys
import unittest

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai.preprocessing import (
    validate_barcode, validate_product_input, ValidationError,
    clean_ingredients, classify_ingredient, normalize_per_100,
)


class TestPreprocessing(unittest.TestCase):
    def test_valid_barcode(self):
        self.assertEqual(validate_barcode(" 12345678 "), "12345678")

    def test_empty_barcode_fails(self):
        with self.assertRaises(ValidationError):
            validate_barcode("")

    def test_non_numeric_barcode_fails(self):
        with self.assertRaises(ValidationError):
            validate_barcode("ABC12345")

    def test_negative_value_fails(self):
        data = {"barcode": "12345678", "product_name": "منتج", "serving_size": "100", "sugar": "-5"}
        with self.assertRaises(ValidationError):
            validate_product_input(data)

    def test_missing_serving_size_fails(self):
        data = {"barcode": "12345678", "product_name": "منتج", "serving_size": "0"}
        with self.assertRaises(ValidationError):
            validate_product_input(data)

    def test_saturated_fat_greater_than_total_fat_fails(self):
        data = {
            "barcode": "12345678", "product_name": "منتج", "serving_size": "100",
            "total_fat": "2", "saturated_fat": "5",
        }
        with self.assertRaises(ValidationError):
            validate_product_input(data)

    def test_valid_input_passes(self):
        data = {
            "barcode": "12345678", "product_name": "منتج سليم", "serving_size": "100",
            "sugar": "10", "total_fat": "5", "saturated_fat": "2", "carbohydrates": "20",
            "fiber": "3", "ingredients": "ماء، سكر،، ملح",
        }
        cleaned = validate_product_input(data)
        self.assertEqual(cleaned["product_name"], "منتج سليم")
        self.assertEqual(len(cleaned["ingredients"]), 3)  # العنصر الفارغ أُزيل

    def test_arabic_comma_split(self):
        items = clean_ingredients("ماء، سكر، ملح")
        self.assertEqual(len(items), 3)
        self.assertEqual(items[0]["name"], "ماء")

    def test_classify_ingredient(self):
        self.assertEqual(classify_ingredient("بنزوات الصوديوم"), "preservative")
        self.assertEqual(classify_ingredient("ماء"), "natural")

    def test_normalize_per_100(self):
        nutrition = {"sugar": 25, "sodium": 200, "preservatives_count": 2,
                     "total_fat": 0, "saturated_fat": 0, "carbohydrates": 0,
                     "fiber": 0, "protein": 0, "caffeine": 0, "calories": 0}
        normalized = normalize_per_100(nutrition, serving_size=50, unit="g")
        self.assertEqual(normalized["sugar"], 50)  # 25 لكل 50غ -> 50 لكل 100غ
        self.assertEqual(normalized["preservatives_count"], 2)  # لا يُطبَّع


if __name__ == "__main__":
    unittest.main()
