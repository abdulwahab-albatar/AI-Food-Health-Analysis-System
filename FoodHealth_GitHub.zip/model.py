# ai/model.py
"""
================================================================
   مكوّن Machine Learning اختياري وإضافي (Hybrid AI Component)
================================================================

هام جدًا (أمانة أكاديمية):
    محرك القرار الأساسي في هذا المشروع هو Rule-Based AI (ai/rules_engine.py).
    هذا الملف يضيف مكوّنًا تجريبيًا إضافيًا: نموذج Machine Learning
    (Decision Tree) حقيقي، مُدرَّب فعليًا، بدقة (Accuracy) محسوبة فعليًا
    من نتائج اختبار حقيقية — وليست رقمًا مُختلَقًا.

    لا تدّعِ أن هذا هو المكوّن الرئيسي للمشروع عند الشرح؛ صرّح دائمًا أنه
    "مكوّن Machine Learning تجريبي إضافي (Hybrid AI)" منفصل عن محرك
    القواعد الأساسي.

مصدر الـ Labels (مهم جدًا للشرح أمام الدكتور):
    الـ Labels هنا **ليست عشوائية** ولم تُخترع لرفع الدقة صناعيًا.
    مصدرها هو نفسه محرك Rule-Based الموجود بالمشروع (rules_engine.py)،
    مطبّقًا على قيم غذائية عشوائية ولكن واقعية النطاق (Synthetic-but-
    Realistic Dataset). أي أن النموذج يتعلّم أن "يقلّد" منطق الخبير
    (Rule-Based) بدلاً من قواعد يدوية، وهذا نمط معروف أكاديميًا يسمى:
    "Learning from a Rule-Based Oracle" ويُستخدم كثيرًا لتوليد بيانات
    تدريب عند غياب بيانات مصنّفة يدويًا من خبراء تغذية حقيقيين.
    هذا موضّح صراحة، ولا يُقدَّم على أنه بيانات ميدانية حقيقية.

Pipeline (Training Pipeline):
    Dataset Generation -> Features -> Train/Test Split (80/20)
    -> Training (DecisionTreeClassifier) -> Evaluation (Accuracy/Precision/
    Recall/F1/Confusion Matrix) -> Save Model (joblib)

تشغيل التدريب:
    python -m ai.model
"""

import os
import sys
import json
import random

import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, confusion_matrix,
)
import joblib

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from ai.rules_engine import evaluate_product

FEATURES = ["sugar", "sodium", "saturated_fat", "total_fat", "fiber", "caffeine", "preservatives_count"]


def generate_dataset(n_samples=1200, seed=42):
    """
    يولّد بيانات تدريب (Dataset) بقيم غذائية عشوائية ولكن ضمن نطاقات واقعية،
    ثم يستخدم محرك Rule-Based لتوليد الـ Label الحقيقي لكل عيّنة (Oracle Labeling).
    """
    rng = random.Random(seed)
    rows = []
    for _ in range(n_samples):
        sample = {
            "sugar": round(rng.uniform(0, 40), 2),
            "sodium": round(rng.uniform(0, 1200), 1),
            "saturated_fat": round(rng.uniform(0, 15), 2),
            "total_fat": round(rng.uniform(0, 30), 2),
            "fiber": round(rng.uniform(0, 12), 2),
            "protein": round(rng.uniform(0, 20), 2),
            "carbohydrates": round(rng.uniform(0, 60), 2),
            "calories": round(rng.uniform(20, 500), 1),
            "caffeine": round(rng.uniform(0, 300), 1),
            "preservatives_count": rng.randint(0, 6),
        }
        # ضمان اتساق منطقي بسيط (saturated_fat <= total_fat)
        if sample["saturated_fat"] > sample["total_fat"]:
            sample["saturated_fat"], sample["total_fat"] = sample["total_fat"], sample["saturated_fat"]

        result = evaluate_product(sample, ingredients=[], health_condition="general")
        sample["label"] = result["risk_level"]
        rows.append(sample)

    df = pd.DataFrame(rows)
    os.makedirs(os.path.dirname(config.DATASET_PATH), exist_ok=True)
    df.to_csv(config.DATASET_PATH, index=False)
    return df


def train_and_evaluate(df=None, test_size=0.2, seed=42):
    """
    ينفّذ Pipeline التدريب الكامل ويعيد Metrics حقيقية.
    Train/Test Split: 80% / 20% (test_size=0.2) — كما هو محدد في الكود فعليًا.
    """
    if df is None:
        if os.path.exists(config.DATASET_PATH):
            df = pd.read_csv(config.DATASET_PATH)
        else:
            df = generate_dataset()

    X = df[FEATURES]
    y = df["label"]

    # Train/Test Split — يتم التقسيم قبل أي معالجة لمنع Data Leakage
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=seed, stratify=y
    )

    model = DecisionTreeClassifier(max_depth=6, random_state=seed)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    metrics = {
        "accuracy": round(accuracy_score(y_test, y_pred), 4),
        "precision_macro": round(precision_score(y_test, y_pred, average="macro", zero_division=0), 4),
        "recall_macro": round(recall_score(y_test, y_pred, average="macro", zero_division=0), 4),
        "f1_macro": round(f1_score(y_test, y_pred, average="macro", zero_division=0), 4),
        "confusion_matrix": confusion_matrix(y_test, y_pred, labels=["SAFE", "CAUTION", "UNSAFE"]).tolist(),
        "labels_order": ["SAFE", "CAUTION", "UNSAFE"],
        "train_size": len(X_train),
        "test_size": len(X_test),
        "train_ratio": round(len(X_train) / len(df), 2),
        "test_ratio": round(len(X_test) / len(df), 2),
    }

    os.makedirs(os.path.dirname(config.MODEL_PATH), exist_ok=True)
    joblib.dump(model, config.MODEL_PATH)

    metrics_path = os.path.join(os.path.dirname(config.MODEL_PATH), "metrics.json")
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)

    return model, metrics


def predict_with_model(nutrition_normalized: dict):
    """يحمّل النموذج المحفوظ ويصنّف عيّنة واحدة (لأغراض العرض/المقارنة فقط)."""
    if not os.path.exists(config.MODEL_PATH):
        raise FileNotFoundError("النموذج غير مدرَّب بعد. شغّل: python -m ai.model")
    model = joblib.load(config.MODEL_PATH)
    row = [[nutrition_normalized.get(f, 0) for f in FEATURES]]
    prediction = model.predict(row)[0]
    return prediction


if __name__ == "__main__":
    print("توليد Dataset...")
    dataset = generate_dataset()
    print(f"تم توليد {len(dataset)} عيّنة. توزيع الفئات:\n{dataset['label'].value_counts()}")

    print("\nتدريب النموذج (Decision Tree)...")
    _, metrics = train_and_evaluate(dataset)

    print("\n== نتائج التقييم (حقيقية من الاختبار) ==")
    for k, v in metrics.items():
        print(f"{k}: {v}")
