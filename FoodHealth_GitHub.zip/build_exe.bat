@echo off
title FoodHealth - Build Desktop Application

echo ============================================
echo       Building FoodHealth Desktop App
echo ============================================
echo.

echo [1/4] Installing requirements...
python -m pip install -r requirements.txt

echo.
echo [2/4] Cleaning previous build...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist FoodHealth.spec del /q FoodHealth.spec

echo.
echo [3/4] Building FoodHealth.exe...
pyinstaller --noconfirm --clean --onedir --windowed ^
    --name "FoodHealth" ^
    --add-data "templates;templates" ^
    --add-data "static;static" ^
    --add-data "data;data" ^
    --add-data "models;models" ^
    --add-data ".env;." ^
    --hidden-import "webview" ^
    --hidden-import "cv2" ^
    --hidden-import "sklearn.tree" ^
    --hidden-import "sklearn.utils._typedefs" ^
    desktop_launcher.py

echo.
echo [4/4] Build completed.
echo.
echo ============================================
echo FoodHealth.exe:
echo dist\FoodHealth\FoodHealth.exe
echo ============================================
echo.

pause