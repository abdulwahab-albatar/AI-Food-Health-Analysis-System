# routes/api.py
"""
Routes خاصة بواجهة JSON API: الباركود عبر الكاميرا، والبحث الخارجي.
"""

from flask import Blueprint, request, jsonify

from database import db_helper
from utils.barcode_utils import detect_barcode_from_image
from ai.preprocessing import validate_barcode, ValidationError
from services import food_api

api_bp = Blueprint("api", __name__, url_prefix="/api")


@api_bp.route("/scan-barcode", methods=["POST"])
def scan_barcode():
    """
    يستقبل صورة (Base64) ملتقطة من كاميرا المتصفح عبر JavaScript،
    ويحاول اكتشاف باركود بداخلها باستخدام OpenCV.
    """
    payload = request.get_json(silent=True) or {}
    image_b64 = payload.get("image")
    if not image_b64:
        return jsonify({"found": False, "error": "لم يتم إرسال صورة."}), 400

    result = detect_barcode_from_image(image_b64)

    if result["found"]:
        # تحقق إضافي من صحة تنسيق الباركود المكتشف
        try:
            validate_barcode(result["barcode"])
        except ValidationError:
            result["found"] = False
            result["error"] = "تم اكتشاف نص، لكنه ليس باركودًا صالحًا."

    return jsonify(result)


@api_bp.route("/lookup/<barcode>")
def lookup_barcode(barcode):
    """
    يبحث عن منتج بالباركود:
        1. أولًا في قاعدة البيانات المحلية.
        2. إذا لم يوجد، يحاول جلبه من API خارجي (Open Food Facts).
    """
    try:
        barcode = validate_barcode(barcode)
    except ValidationError as e:
        return jsonify({"status": "error", "message": str(e)}), 400

    local = db_helper.get_product_by_barcode(barcode)
    if local:
        return jsonify({"status": "found_local", "data": local})

    external = food_api.fetch_product_by_barcode(barcode)
    return jsonify(external)
