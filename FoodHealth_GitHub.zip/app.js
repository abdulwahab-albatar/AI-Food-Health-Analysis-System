/**
 * app.js
 * ماسح باركود تلقائي باستخدام كاميرا اللابتوب.
 *
 * الوظيفة:
 * 1. فتح كاميرا اللابتوب.
 * 2. عرض الصورة مباشرة.
 * 3. التقاط إطارات تلقائيًا.
 * 4. إرسالها إلى Backend لفحص الباركود.
 * 5. عند العثور على الباركود يتم وضعه في خانة barcode.
 * 6. إيقاف الكاميرا تلقائيًا.
 */

let activeStream = null;
let scanTimer = null;
let isScanning = false;


/* =========================================================
   تهيئة ماسح الباركود
   ========================================================= */

function initBarcodeScanner(opts) {

    const scanBtn =
        document.getElementById(opts.scanBtnId);

    const cameraArea =
        document.getElementById(opts.cameraAreaId);

    const video =
        document.getElementById(opts.videoId);

    const canvas =
        document.getElementById(opts.canvasId);

        const closeBtn =
        document.getElementById(opts.closeBtnId);

    const statusEl =
        document.getElementById(opts.statusId);

    const barcodeInput =
        document.getElementById(opts.barcodeInputId);


    if (!scanBtn) {
        console.log("Barcode scanner: scan button not found.");
        return;
    }


    if (
        !cameraArea ||
        !video ||
        !canvas ||
        !closeBtn ||
        !statusEl ||
        !barcodeInput
    ) {
        console.error(
            "Barcode scanner: required elements are missing."
        );
        return;
    }


    /* =====================================================
       فتح الكاميرا
       ===================================================== */

    scanBtn.addEventListener("click", async function () {

        console.log(
            "Barcode scanner: opening laptop camera..."
        );


        statusEl.textContent =
            "جاري تشغيل كاميرا اللابتوب...";


        cameraArea.classList.remove("hidden");


        try {

            /* إيقاف أي كاميرا سابقة */
            stopActiveStream();


            /* =================================================
               تشغيل كاميرا الجهاز
               ================================================= */

            activeStream =
                await openPreferredCamera();


            console.log(
                "Laptop camera started successfully."
            );


            video.srcObject =
                activeStream;


            await video.play();


            statusEl.textContent =
                "وجّه الباركود أمام الكاميرا... سيتم التقاطه تلقائيًا.";


            /*
             * نبدأ الفحص التلقائي
             */

            startAutomaticScanning();


        }

        catch (error) {

            console.error(
                "Camera error:",
                error
            );


            cameraArea.classList.add("hidden");


            let message =
                "تعذر تشغيل كاميرا اللابتوب.";


            if (error.name === "NotAllowedError") {

                message =
                    "تم رفض صلاحية الكاميرا. اسمح للمتصفح باستخدام كاميرا اللابتوب.";

            }

            else if (error.name === "NotFoundError") {

                message =
                    "لم يتم العثور على كاميرا في اللابتوب.";

            }

            else if (error.name === "NotReadableError") {

                message =
                    "كاميرا اللابتوب مستخدمة حاليًا من برنامج آخر. أغلق Zoom أو Teams أو أي برنامج يستخدم الكاميرا.";

            }

            else if (error.name === "SecurityError") {

                message =
                    "المتصفح منع الوصول إلى الكاميرا لأسباب أمنية.";

            }

            else {

                message =
                    "خطأ في الكاميرا: " +
                    error.name +
                    " - " +
                    error.message;

            }


            statusEl.textContent =
                message;

        }

    });


    /* =====================================================
       الفحص التلقائي
       ===================================================== */

    function startAutomaticScanning() {

        if (isScanning) {
            return;
        }


        isScanning = true;


        console.log(
            "Automatic barcode scanning started."
        );


        /*
         * نفحص صورة من الكاميرا كل 300ms تقريبًا.
         */

        scanTimer =
            setInterval(
                function () {

                    scanCurrentFrame();

                },
                300
            );

    }


    /* =====================================================
       فحص الإطار الحالي
       ===================================================== */

    async function scanCurrentFrame() {

        if (!isScanning) {
            return;
        }


        if (!activeStream) {
            return;
        }


        if (
            video.readyState < 2 ||
            !video.videoWidth ||
            !video.videoHeight
        ) {

            return;

        }


        /*
         * منع إرسال أكثر من صورة في نفس الوقت.
         */

        if (video.dataset.scanning === "true") {
            return;
        }


        video.dataset.scanning = "true";


        try {

            /*
             * تجهيز Canvas
             */

            canvas.width =
                video.videoWidth;

            canvas.height =
                video.videoHeight;


            const ctx =
                canvas.getContext("2d");


            if (!ctx) {
                throw new Error(
                    "تعذر إنشاء Canvas."
                );
            }


            /*
             * التقاط الإطار الحالي من الكاميرا
             */

            ctx.drawImage(
                video,
                0,
                0,
                canvas.width,
                canvas.height
            );


            /*
             * تحويل الصورة إلى JPEG
             */

            const base64Image =
                canvas.toDataURL(
                    "image/jpeg",
                    0.85
                );


            /*
             * إرسال الصورة إلى Backend
             */

            const response =
                await fetch(
                    opts.scanEndpoint,
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            image: base64Image
                        })
                    }
                );


            if (!response.ok) {

                throw new Error(
                    "HTTP " +
                    response.status
                );

            }


            const data =
                await response.json();


            console.log(
                "Automatic barcode scan:",
                data
            );


            /*
             * =================================================
             * تم العثور على الباركود
             * =================================================
             */

            if (data.found && data.barcode) {

                console.log(
                    "Barcode found:",
                    data.barcode
                );


                /*
                 * وضع الباركود في خانة الإدخال
                 */

                barcodeInput.value =
                    data.barcode;


                /*
                 * إيقاف الفحص التلقائي
                 */

                stopAutomaticScanning();


                /*
                 * إظهار رسالة النجاح
                 */

                statusEl.textContent =
                    "✓ تم اكتشاف الباركود تلقائيًا: " +
                    data.barcode;


                /*
                 * إيقاف الكاميرا
                 */

                stopCamera(
                    true
                );


                /*
                 * تشغيل حدث input
                 * حتى تتعرف بقية JavaScript
                 * على القيمة الجديدة.
                 */

                barcodeInput.dispatchEvent(
                    new Event(
                        "input",
                        {
                            bubbles: true
                        }
                    )
                );


                barcodeInput.dispatchEvent(
                    new Event(
                        "change",
                        {
                            bubbles: true
                        }
                    )
                );

            }


        }

        catch (error) {

            console.error(
                "Automatic barcode scan error:",
                error
            );

        }

        finally {

            video.dataset.scanning =
                "false";

        }

    }


    /* =====================================================
       إيقاف الفحص التلقائي
       ===================================================== */

    function stopAutomaticScanning() {

        isScanning = false;


        if (scanTimer) {

            clearInterval(
                scanTimer
            );

            scanTimer = null;

        }


        console.log(
            "Automatic barcode scanning stopped."
        );

    }


    /* =====================================================
       زر إغلاق الكاميرا
       ===================================================== */

    closeBtn.addEventListener(
        "click",
        function () {

            stopCamera(
                false
            );

        }
    );


    /* =====================================================
       إيقاف الكاميرا
       ===================================================== */

    function stopCamera(
        keepStatus = false
    ) {

        console.log(
            "Stopping laptop camera."
        );


        stopAutomaticScanning();


        stopActiveStream();


        video.srcObject =
            null;


        video.removeAttribute(
            "data-scanning"
        );


        cameraArea.classList.add(
            "hidden"
        );


        if (!keepStatus) {

            statusEl.textContent =
                "";

        }

    }

}


/* =========================================================
   اختيار كاميرا الجهاز بشكل آمن
   ========================================================= */

async function openPreferredCamera() {

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("المتصفح لا يدعم الوصول إلى الكاميرا.");
    }

    /*
     * نبدأ بطلب عام للكاميرا. هذه الخطوة مهمة لأن المتصفح غالبًا
     * لا يكشف أسماء أجهزة الفيديو قبل منح الإذن. لا يوجد deviceId
     * محفوظ أو hard-coded هنا.
     */
    let stream = await navigator.mediaDevices.getUserMedia({
        video: {
            width: { ideal: 1280 },
            height: { ideal: 720 },
            facingMode: { ideal: "user" }
        },
        audio: false
    });

    try {
        const track = stream.getVideoTracks()[0];
        const currentDeviceId = track && track.getSettings
            ? track.getSettings().deviceId
            : "";

        if (!navigator.mediaDevices.enumerateDevices) {
            return stream;
        }

        const devices = await navigator.mediaDevices.enumerateDevices();
        const cameras = devices.filter(function (device) {
            return device.kind === "videoinput";
        });

        if (!cameras.length) {
            return stream;
        }

        const preferred = cameras
            .map(function (camera) {
                const name = (camera.label || "").toLowerCase();
                let score = 0;

                /* أسماء شائعة للكاميرا المدمجة في اللابتوب. */
                if (name.includes("integrated")) score += 100;
                if (name.includes("built-in")) score += 100;
                if (name.includes("built in")) score += 100;
                if (name.includes("internal")) score += 90;
                if (name.includes("laptop")) score += 80;
                if (name.includes("hd camera")) score += 70;
                if (name.includes("hd webcam")) score += 70;
                if (name.includes("webcam")) score += 30;

                /*
                 * لا نعتمد على اسم DroidCam وحده؛ نخفض أولوية
                 * الكاميرات الافتراضية عمومًا حتى لا يتم اختيارها
                 * تلقائيًا عندما توجد كاميرا مدمجة حقيقية.
                 */
                if (name.includes("virtual")) score -= 100;
                if (name.includes("droidcam")) score -= 100;
                if (name.includes("obs camera")) score -= 80;
                if (name.includes("snap camera")) score -= 80;
                if (name.includes("manycam")) score -= 80;
                if (name.includes("virtual camera")) score -= 100;

                if (camera.deviceId === currentDeviceId) score += 5;

                return { camera: camera, score: score };
            })
            .sort(function (a, b) {
                return b.score - a.score;
            })[0];

        /*
         * إذا لم توجد إشارة موثوقة إلى كاميرا أفضل، نحافظ على
         * اختيار المتصفح الحالي بدل فرض جهاز عشوائي.
         */
        if (!preferred || preferred.camera.deviceId === currentDeviceId || preferred.score < 70) {
            return stream;
        }

        /* تبديل آمن إلى الكاميرا المفضلة فقط عندما توجد إشارة واضحة. */
        stream.getTracks().forEach(function (oldTrack) {
            oldTrack.stop();
        });

        return await navigator.mediaDevices.getUserMedia({
            video: {
                deviceId: { exact: preferred.camera.deviceId },
                width: { ideal: 1280 },
                height: { ideal: 720 }
            },
            audio: false
        });

    } catch (selectionError) {
        /* فشل عملية الاختيار لا يمنع استخدام الكاميرا التي فتحها المتصفح. */
        console.warn("Camera preference selection failed; using the initial camera.", selectionError);
        return stream;
    }
}


/* =========================================================
   إيقاف Stream الحالي
   ========================================================= */

function stopActiveStream() {

    if (!activeStream) {
        return;
    }


    activeStream
        .getTracks()
        .forEach(
            function (track) {

                track.stop();

            }
        );


    activeStream =
        null;


    console.log(
        "Camera stream stopped."
    );

}


/* =========================================================
   عند مغادرة الصفحة
   ========================================================= */

window.addEventListener(
    "beforeunload",
    function () {

        if (activeStream) {

            activeStream
                .getTracks()
                .forEach(
                    function (track) {

                        track.stop();

                    }
                );

        }

    }
);
