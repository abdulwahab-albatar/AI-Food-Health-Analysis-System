import json
import os
import urllib.request
from datetime import datetime

from database import db_helper
import config


def export_products():
    """Export all local products as JSON."""

    products = db_helper.list_products(limit=10000)

    result = []

    for product in products:
        product_id = product["product_id"]

        full_product = db_helper.get_product_by_id(product_id)

        if not full_product:
            continue

        nutrition = full_product.get("nutrition", {})
        ingredients_rows = full_product.get("ingredients", [])

        ingredients = []

        for ingredient in ingredients_rows:
            ingredients.append({
                "name": ingredient["ingredient_name"],
                "type": ingredient.get("ingredient_type", "natural")
            })

        result.append({
            "barcode": product["barcode"],
            "product_name": product["product_name"],
            "manufacturer": product.get("manufacturer"),
            "category": product.get("category"),
            "serving_size": product.get("serving_size", 0),
            "unit": product.get("unit", "g"),
            "nutrition": {
                "calories": nutrition.get("calories", 0),
                "sugar": nutrition.get("sugar", 0),
                "total_fat": nutrition.get("total_fat", 0),
                "saturated_fat": nutrition.get("saturated_fat", 0),
                "carbohydrates": nutrition.get("carbohydrates", 0),
                "fiber": nutrition.get("fiber", 0),
                "protein": nutrition.get("protein", 0),
                "sodium": nutrition.get("sodium", 0),
                "caffeine": nutrition.get("caffeine", 0),
                "preservatives_count": nutrition.get(
                    "preservatives_count",
                    0
                )
            },
            "ingredients": ingredients
        })

    return {
        "success": True,
        "version": 1,
        "generated_at": datetime.now().isoformat(
            timespec="seconds"
        ),
        "product_count": len(result),
        "products": result
    }


def import_products(data):
    """Import or update products in the local database."""

    if not isinstance(data, dict):
        raise ValueError("Invalid sync data")

    products = data.get("products", [])

    if not isinstance(products, list):
        raise ValueError("Invalid products data")

    imported = 0
    updated = 0
    skipped = 0
    errors = []

    for product in products:

        try:
            if not isinstance(product, dict):
                skipped += 1
                continue

            barcode = str(
                product.get("barcode", "")
            ).strip()

            if not barcode:
                skipped += 1
                continue

            existing = db_helper.get_product_by_barcode(
                barcode
            )

            if existing:

                product_id = existing["product"]["product_id"]

                db_helper.update_product(
                    product_id=product_id,
                    product_name=product.get(
                        "product_name",
                        existing["product"].get(
                            "product_name",
                            ""
                        )
                    ),
                    manufacturer=product.get(
                        "manufacturer",
                        existing["product"].get(
                            "manufacturer"
                        )
                    ),
                    category=product.get(
                        "category",
                        existing["product"].get(
                            "category"
                        )
                    ),
                    serving_size=product.get(
                        "serving_size",
                        existing["product"].get(
                            "serving_size",
                            0
                        )
                    ),
                    unit=product.get(
                        "unit",
                        existing["product"].get(
                            "unit",
                            "g"
                        )
                    ),
                    nutrition=product.get(
                        "nutrition",
                        {}
                    ),
                    ingredients=product.get(
                        "ingredients",
                        []
                    )
                )

                updated += 1

            else:

                db_helper.create_product(
                    barcode=barcode,
                    product_name=product.get(
                        "product_name",
                        "Unknown Product"
                    ),
                    manufacturer=product.get(
                        "manufacturer"
                    ),
                    category=product.get(
                        "category"
                    ),
                    serving_size=product.get(
                        "serving_size",
                        0
                    ),
                    unit=product.get(
                        "unit",
                        "g"
                    ),
                    nutrition=product.get(
                        "nutrition",
                        {}
                    ),
                    ingredients=product.get(
                        "ingredients",
                        []
                    )
                )

                imported += 1

        except Exception as exc:

            errors.append({
                "barcode": product.get("barcode"),
                "product_name": product.get(
                    "product_name"
                ),
                "error": str(exc)
            })

            skipped += 1

    return {
        "success": len(errors) == 0,
        "received": len(products),
        "imported": imported,
        "updated": updated,
        "skipped": skipped,
        "errors": errors
    }


def export_to_file(file_path):
    """Export local products to a JSON file."""

    data = export_products()

    folder = os.path.dirname(file_path)

    if folder:
        os.makedirs(
            folder,
            exist_ok=True
        )

    with open(
        file_path,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            data,
            file,
            ensure_ascii=False,
            indent=2
        )

    return file_path


def import_from_file(file_path):
    """Import products from a JSON file."""

    if not os.path.exists(file_path):
        raise FileNotFoundError(
            file_path
        )

    with open(
        file_path,
        "r",
        encoding="utf-8"
    ) as file:

        data = json.load(file)

    return import_products(data)


def _get_sync_server_url():
    """Return the configured central synchronization server URL."""

    url = getattr(
        config,
        "SYNC_SERVER_URL",
        ""
    )

    if not url:
        return ""

    return str(url).strip().rstrip("/")


def _cloud_request(
    path,
    method="GET",
    data=None
):
    """Send a request to the central synchronization server."""

    base_url = _get_sync_server_url()

    if not base_url:
        raise RuntimeError(
            "SYNC_SERVER_URL is not configured"
        )

    url = (
        base_url
        + "/"
        + path.lstrip("/")
    )

    body = None

    headers = {
        "Accept": "application/json"
    }

    if data is not None:

        body = json.dumps(
            data,
            ensure_ascii=False
        ).encode("utf-8")

        headers["Content-Type"] = (
            "application/json"
        )

    request = urllib.request.Request(
        url=url,
        data=body,
        headers=headers,
        method=method
    )

    timeout = getattr(
        config,
        "SYNC_TIMEOUT",
        15
    )

    with urllib.request.urlopen(
        request,
        timeout=timeout
    ) as response:

        raw = response.read().decode(
            "utf-8"
        )

        if not raw:
            return {}

        return json.loads(raw)


def export_to_cloud():
    """Upload local products to the central server."""

    data = export_products()

    return _cloud_request(
        "/api/sync/import",
        method="POST",
        data=data
    )


def import_from_cloud():
    """Download products from the central server."""

    data = _cloud_request(
        "/api/sync/export",
        method="GET"
    )

    return import_products(data)


def cloud_status():
    """Check the central synchronization server."""

    data = _cloud_request(
        "/api/sync/status",
        method="GET"
    )

    return {
        "success": True,
        "online": True,
        "server": data
    }


def sync_with_cloud():
    """
    Synchronize local database with the central server.

    If the Internet or server is unavailable,
    the local database continues working normally.
    """

    result = {
        "success": False,
        "online": False,
        "synced": False,
        "imported": 0,
        "updated": 0,
        "skipped": 0,
        "errors": [],
        "message": ""
    }

    sync_enabled = getattr(
        config,
        "SYNC_ENABLED",
        True
    )

    if not sync_enabled:

        result["message"] = (
            "Cloud synchronization is disabled."
        )

        return result

    server_url = _get_sync_server_url()

    if not server_url:

        result["message"] = (
            "Cloud synchronization is not configured. "
            "Using local database."
        )

        return result

    try:

        cloud_data = _cloud_request(
            "/api/sync/export",
            method="GET"
        )

        if not isinstance(
            cloud_data,
            dict
        ):

            raise ValueError(
                "Invalid response from central sync server"
            )

        import_result = import_products(
            cloud_data
        )

        result.update({
            "success": import_result.get(
                "success",
                False
            ),
            "online": True,
            "synced": import_result.get(
                "success",
                False
            ),
            "imported": import_result.get(
                "imported",
                0
            ),
            "updated": import_result.get(
                "updated",
                0
            ),
            "skipped": import_result.get(
                "skipped",
                0
            ),
            "errors": import_result.get(
                "errors",
                []
            ),
            "message": (
                "Cloud synchronization completed."
            )
        })

        return result

    except Exception as exc:

        result["online"] = False
        result["synced"] = False

        result["message"] = (
            "Cloud synchronization unavailable. "
            "Using local database."
        )

        result["errors"] = [
            str(exc)
        ]

        return result


def sync_on_startup():
    """
    Run cloud synchronization when FoodHealth starts.

    If cloud synchronization is unavailable,
    the application continues normally using
    the local database.
    """

    try:

        result = sync_with_cloud()

        if (
            result.get("online")
            and result.get("synced")
        ):

            print(
                "* Cloud synchronization completed."
            )

        else:

            print(
                "* Cloud synchronization unavailable."
            )

            print(
                "* Continuing with local database "
                "(Offline Mode)."
            )

        return result

    except Exception as exc:

        print(
            "* Cloud synchronization unavailable."
        )

        print(
            "* Continuing with local database "
            "(Offline Mode)."
        )

        return {
            "success": False,
            "online": False,
            "synced": False,
            "imported": 0,
            "updated": 0,
            "skipped": 0,
            "errors": [
                str(exc)
            ],
            "message": (
                "Cloud synchronization unavailable. "
                "Using local database."
            )
        }