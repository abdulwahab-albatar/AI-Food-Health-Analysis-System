# utils/barcode_utils.py
"""
أدوات الباركود.

يدعم النظام طريقتين لإدخال الباركود:
    1. Manual Entry  -> يُعالَج في ai/preprocessing.validate_barcode()
    2. Camera        -> هذا الملف، باستخدام OpenCV (cv2.barcode.BarcodeDetector)

لماذا OpenCV فقط وليس PyZbar؟
    تم اختيار cv2.barcode.BarcodeDetector (متوفر منذ OpenCV 4.5.1+ عبر
    opencv-contrib-python) بدلاً من مكتبة pyzbar لتقليل الاعتمادات
    الخارجية (Dependencies) وتسهيل تحويل المشروع إلى EXE لاحقًا،
    مع تحقيق نفس الهدف الوظيفي: Computer Vision لاكتشاف الباركود.

Algorithm Location:
    File     -> utils/barcode_utils.py
    Function -> detect_barcode_from_image()
    Called from -> routes/api.py  (POST /api/scan-barcode)

تدفق العمل (Workflow):
    الكاميرا (من المتصفح عبر JavaScript)
        -> صورة (Base64 من <video>/<canvas>)
        -> Backend يفك التشفير
        -> cv2.barcode.BarcodeDetector
        -> رقم الباركود (إن وُجد)
        -> البحث في قاعدة البيانات
"""

import base64
import numpy as np

try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False


def decode_base64_image(base64_string: str):
    """يحوّل صورة Base64 (قادمة من JavaScript/Canvas) إلى مصفوفة OpenCV."""
    if "," in base64_string:
        base64_string = base64_string.split(",")[1]
    img_bytes = base64.b64decode(base64_string)
    np_arr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    return img


def detect_barcode_from_image(base64_string: str):
    """
    يحاول اكتشاف باركود داخل صورة واحدة.

    Returns:
        dict: {"found": bool, "barcode": str|None, "error": str|None}
    """
    if not CV2_AVAILABLE:
        return {"found": False, "barcode": None, "error": "مكتبة OpenCV غير متوفرة على الخادم."}

    try:
        img = decode_base64_image(base64_string)
        if img is None:
            return {"found": False, "barcode": None, "error": "تعذّر قراءة الصورة المرسلة."}

        detector = cv2.barcode.BarcodeDetector()
        result = detector.detectAndDecode(img)
        if len(result) == 4:
            ok, decoded_info, decoded_type, points = result
        elif len(result) == 3:
            decoded_info, decoded_type, points = result
            ok = bool(decoded_info and any(decoded_info))
        else:
            return {"found": False, "barcode": None, "error": "استجابة غير متوقعة من OpenCV BarcodeDetector."}

        if ok and decoded_info:
            for value in decoded_info:
                if value:  # قد يعيد قيمًا فارغة لباركودات لم تُفَك بنجاح
                    return {"found": True, "barcode": value, "error": None}

        return {"found": False, "barcode": None, "error": "لم يتم العثور على باركود واضح في الصورة."}

    except Exception as e:
        return {"found": False, "barcode": None, "error": f"خطأ أثناء معالجة الصورة: {e}"}
