@echo off

call C:\Users\tss\.conda\Scripts\activate.bat foodhealth

cd /d "D:\AI\Code\نظام ذكي لتحليل المنتجات الغذائية وتقييم ملاءمتها الصحية باستخدام الذكاء الاصطناعي\foodhealth"

python desktop.py