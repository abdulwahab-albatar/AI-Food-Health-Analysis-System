# migrate_to_supabase.py
#
# FoodHealth
# ظ†ظ‚ظ„ ط§ظ„ط¨ظٹط§ظ†ط§طھ ظ…ظ† SQLite ط§ظ„ظ…ط­ظ„ظٹط© ط¥ظ„ظ‰ Supabase
#
# IMPORTANT:
# - ظ„ط§ ظٹط­ط°ظپ ط£ظٹ ط¨ظٹط§ظ†ط§طھ ظ…ظ† SQLite.
# - ظٹظ†ظ‚ظ„ ط§ظ„ظ…ظ†طھط¬ط§طھ ظˆط§ظ„ط¨ظٹط§ظ†ط§طھ ط§ظ„ط؛ط°ط§ط¦ظٹط© ظˆط§ظ„ظ…ظƒظˆظ†ط§طھ ظˆط§ظ„طھظ‚ظٹظٹظ…ط§طھ.
# - ظٹط³طھط®ط¯ظ… barcode ظ„ظ…ظ†ط¹ طھظƒط±ط§ط± ط§ظ„ظ…ظ†طھط¬ط§طھ.
# - ظٹظ…ظƒظ† طھط´ط؛ظٹظ„ظ‡ ط£ظƒط«ط± ظ…ظ† ظ…ط±ط© ط¨ط£ظ…ط§ظ† ظ†ط³ط¨ظٹظ‹ط§.

import os
import sqlite3

from dotenv import load_dotenv
from supabase import create_client

import config


# ============================================================
# Configuration
# ============================================================

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

if not SUPABASE_URL:
    raise RuntimeError("SUPABASE_URL is missing from .env")

if not SUPABASE_KEY:
    raise RuntimeError("SUPABASE_KEY is missing from .env")


# ============================================================
# Supabase Client
# ============================================================

supabase = create_client(
    SUPABASE_URL,
    SUPABASE_KEY
)


# ============================================================
# Local Database
# ============================================================

DATABASE_PATH = config.DATABASE_PATH


# ============================================================
# Helpers
# ============================================================

def get_value(row, key, default=None):
    """
    Safely get a value from sqlite3.Row.
    """
    try:
        value = row[key]

        if value is None:
            return default

        return value

    except (KeyError, IndexError):
        return default


def clean_text(value):
    """
    Convert a value to clean text.
    """
    if value is None:
        return None

    return str(value).strip()


# ============================================================
# Main Migration
# ============================================================

def migrate():
    print("=" * 60)
    print("FoodHealth - SQLite -> Supabase Migration")
    print("=" * 60)

    print()
    print("Local database:")
    print(DATABASE_PATH)

    print()
    print("Supabase:")
    print(SUPABASE_URL)

    print()
    print("Connecting to local SQLite database...")

    conn = sqlite3.connect(DATABASE_PATH)

    conn.row_factory = sqlite3.Row

    try:

        # ----------------------------------------------------
        # Read all local products
        # ----------------------------------------------------

        products = conn.execute(
            """
            SELECT
                product_id,
                barcode,
                product_name,
                manufacturer,
                category,
                serving_size,
                unit,
                created_at,
                updated_at
            FROM products
            ORDER BY product_id
            """
        ).fetchall()

        print()
        print("Local products found:", len(products))

        if not products:
            print()
            print("No products found in local database.")
            return

        # ----------------------------------------------------
        # Counters
        # ----------------------------------------------------

        inserted_products = 0
        existing_products = 0

        inserted_nutrition = 0
        inserted_ingredients = 0
        inserted_evaluations = 0

        failed_products = 0

        # ----------------------------------------------------
        # Process products
        # ----------------------------------------------------

        for index, product in enumerate(products, start=1):

            product_id = get_value(product, "product_id")

            barcode = clean_text(
                get_value(product, "barcode")
            )

            product_name = clean_text(
                get_value(product, "product_name")
            )

            print()
            print(
                f"[{index}/{len(products)}] "
                f"{product_name} "
                f"(barcode: {barcode})"
            )

            if not barcode:
                print("  WARNING: Product has no barcode.")
                print("  Skipping product.")

                failed_products += 1
                continue

            try:

                # ====================================================
                # Check product in Supabase
                # ====================================================

                existing_response = (
                    supabase
                    .table("products")
                    .select("product_id")
                    .eq("barcode", barcode)
                    .limit(1)
                    .execute()
                )

                existing_data = existing_response.data

                # ====================================================
                # Product already exists
                # ====================================================

                if existing_data:

                    remote_product_id = existing_data[0]["product_id"]

                    print(
                        f"  Product already exists "
                        f"(Supabase ID: {remote_product_id})"
                    )

                    # Update product information.
                    supabase.table("products").update(
                        {
                            "product_name": product_name,
                            "manufacturer": get_value(
                                product,
                                "manufacturer"
                            ),
                            "category": get_value(
                                product,
                                "category"
                            ),
                            "serving_size": get_value(
                                product,
                                "serving_size",
                                0
                            ),
                            "unit": get_value(
                                product,
                                "unit",
                                "g"
                            ),
                            "updated_at": get_value(
                                product,
                                "updated_at"
                            )
                        }
                    ).eq(
                        "product_id",
                        remote_product_id
                    ).execute()

                    existing_products += 1

                # ====================================================
                # New product
                # ====================================================

                else:

                    insert_response = (
                        supabase
                        .table("products")
                        .insert(
                            {
                                "barcode": barcode,
                                "product_name": product_name,
                                "manufacturer": get_value(
                                    product,
                                    "manufacturer"
                                ),
                                "category": get_value(
                                    product,
                                    "category"
                                ),
                                "serving_size": get_value(
                                    product,
                                    "serving_size",
                                    0
                                ),
                                "unit": get_value(
                                    product,
                                    "unit",
                                    "g"
                                ),
                                "created_at": get_value(
                                    product,
                                    "created_at"
                                ),
                                "updated_at": get_value(
                                    product,
                                    "updated_at"
                                )
                            }
                        )
                        .execute()
                    )

                    if not insert_response.data:
                        raise RuntimeError(
                            "Supabase did not return inserted product."
                        )

                    remote_product_id = (
                        insert_response.data[0]["product_id"]
                    )

                    print(
                        f"  Product inserted "
                        f"(Supabase ID: {remote_product_id})"
                    )

                    inserted_products += 1

                # ====================================================
                # Nutrition
                # ====================================================

                nutrition_rows = conn.execute(
                    """
                    SELECT
                        calories,
                        sugar,
                        total_fat,
                        saturated_fat,
                        carbohydrates,
                        fiber,
                        protein,
                        sodium,
                        caffeine,
                        preservatives_count
                    FROM nutrition
                    WHERE product_id = ?
                    """,
                    (product_id,)
                ).fetchall()

                # Remove existing nutrition for this product
                # so repeated migrations do not create duplicates.
                supabase.table("nutrition").delete().eq(
                    "product_id",
                    remote_product_id
                ).execute()

                for nutrition in nutrition_rows:

                    supabase.table("nutrition").insert(
                        {
                            "product_id": remote_product_id,
                            "calories": get_value(
                                nutrition,
                                "calories",
                                0
                            ),
                            "sugar": get_value(
                                nutrition,
                                "sugar",
                                0
                            ),
                            "total_fat": get_value(
                                nutrition,
                                "total_fat",
                                0
                            ),
                            "saturated_fat": get_value(
                                nutrition,
                                "saturated_fat",
                                0
                            ),
                            "carbohydrates": get_value(
                                nutrition,
                                "carbohydrates",
                                0
                            ),
                            "fiber": get_value(
                                nutrition,
                                "fiber",
                                0
                            ),
                            "protein": get_value(
                                nutrition,
                                "protein",
                                0
                            ),
                            "sodium": get_value(
                                nutrition,
                                "sodium",
                                0
                            ),
                            "caffeine": get_value(
                                nutrition,
                                "caffeine",
                                0
                            ),
                            "preservatives_count": get_value(
                                nutrition,
                                "preservatives_count",
                                0
                            )
                        }
                    ).execute()

                    inserted_nutrition += 1

                # ====================================================
                # Ingredients
                # ====================================================

                ingredient_rows = conn.execute(
                    """
                    SELECT
                        ingredient_name,
                        ingredient_type
                    FROM ingredients
                    WHERE product_id = ?
                    ORDER BY ingredient_id
                    """,
                    (product_id,)
                ).fetchall()

                # Remove existing ingredients for this product
                # before inserting the current local copy.
                supabase.table("ingredients").delete().eq(
                    "product_id",
                    remote_product_id
                ).execute()

                for ingredient in ingredient_rows:

                    ingredient_name = clean_text(
                        get_value(
                            ingredient,
                            "ingredient_name"
                        )
                    )

                    if not ingredient_name:
                        continue

                    supabase.table("ingredients").insert(
                        {
                            "product_id": remote_product_id,
                            "ingredient_name": ingredient_name,
                            "ingredient_type": get_value(
                                ingredient,
                                "ingredient_type",
                                "natural"
                            )
                        }
                    ).execute()

                    inserted_ingredients += 1

                # ====================================================
                # Evaluations
                # ====================================================

                evaluation_rows = conn.execute(
                    """
                    SELECT
                        health_condition,
                        score,
                        risk_level,
                        recommendation,
                        detected_risks_json,
                        evaluation_date
                    FROM evaluations
                    WHERE product_id = ?
                    ORDER BY evaluation_id
                    """,
                    (product_id,)
                ).fetchall()

                # Remove existing evaluations for this product
                # before inserting the current local copy.
                supabase.table("evaluations").delete().eq(
                    "product_id",
                    remote_product_id
                ).execute()

                for evaluation in evaluation_rows:

                    supabase.table("evaluations").insert(
                        {
                            "product_id": remote_product_id,
                            "health_condition": get_value(
                                evaluation,
                                "health_condition"
                            ),
                            "score": get_value(
                                evaluation,
                                "score",
                                0
                            ),
                            "risk_level": get_value(
                                evaluation,
                                "risk_level"
                            ),
                            "recommendation": get_value(
                                evaluation,
                                "recommendation"
                            ),
                            "detected_risks_json": get_value(
                                evaluation,
                                "detected_risks_json"
                            ),
                            "evaluation_date": get_value(
                                evaluation,
                                "evaluation_date"
                            )
                        }
                    ).execute()

                    inserted_evaluations += 1

                print("  Data synchronized successfully.")

            except Exception as exc:

                failed_products += 1

                print(
                    f"  ERROR: {exc}"
                )

        # ====================================================
        # Final Report
        # ====================================================

        print()
        print("=" * 60)
        print("MIGRATION COMPLETED")
        print("=" * 60)

        print(
            "Local products:",
            len(products)
        )

        print(
            "New products inserted:",
            inserted_products
        )

        print(
            "Existing products updated:",
            existing_products
        )

        print(
            "Nutrition rows:",
            inserted_nutrition
        )

        print(
            "Ingredient rows:",
            inserted_ingredients
        )

        print(
            "Evaluation rows:",
            inserted_evaluations
        )

        print(
            "Failed products:",
            failed_products
        )

        print("=" * 60)

    finally:

        # IMPORTANT:
        # Only closes SQLite connection.
        # It does NOT delete or modify the local database.
        conn.close()


# ============================================================
# Entry Point
# ============================================================

if __name__ == "__main__":
    migrate()