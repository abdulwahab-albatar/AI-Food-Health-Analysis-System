# tests/test_database.py
"""اختبارات قاعدة البيانات: Insert, Read, Update, Delete, Search."""

import os
import sys
import tempfile
import unittest

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config


class TestDatabase(unittest.TestCase):
    def setUp(self):
        # قاعدة بيانات مؤقتة منفصلة لكل اختبار حتى لا تتداخل مع بيانات المستخدم الحقيقية
        self.tmp_dir = tempfile.mkdtemp()
        config.DATABASE_PATH = os.path.join(self.tmp_dir, "test_food_health.db")
        from database import db_helper
        self.db = db_helper
        self.db.init_db()

    def _sample_nutrition(self):
        return {
            "calories": 150, "sugar": 10, "total_fat": 5, "saturated_fat": 2,
            "carbohydrates": 20, "fiber": 3, "protein": 4, "sodium": 200,
            "caffeine": 0, "preservatives_count": 1,
        }

    def test_insert_and_read(self):
        pid = self.db.create_product(
            "11112222", "منتج اختبار", "شركة", "فئة", 100, "g",
            self._sample_nutrition(), [{"name": "سكر", "type": "natural"}],
        )
        self.assertIsNotNone(pid)
        data = self.db.get_product_by_id(pid)
        self.assertEqual(data["product"]["product_name"], "منتج اختبار")
        self.assertEqual(len(data["ingredients"]), 1)

    def test_duplicate_barcode_fails(self):
        self.db.create_product("33334444", "منتج1", "", "", 100, "g", self._sample_nutrition(), [])
        with self.assertRaises(ValueError):
            self.db.create_product("33334444", "منتج2", "", "", 100, "g", self._sample_nutrition(), [])

    def test_update(self):
        pid = self.db.create_product("55556666", "اسم قديم", "", "", 100, "g", self._sample_nutrition(), [])
        self.db.update_product(pid, "اسم جديد", "", "", 100, "g", self._sample_nutrition(), [])
        data = self.db.get_product_by_id(pid)
        self.assertEqual(data["product"]["product_name"], "اسم جديد")

    def test_delete(self):
        pid = self.db.create_product("77778888", "للحذف", "", "", 100, "g", self._sample_nutrition(), [])
        self.db.delete_product(pid)
        self.assertIsNone(self.db.get_product_by_id(pid))

    def test_search(self):
        self.db.create_product("99990000", "بسكويت شوكولاتة", "شركة الحلويات", "", 50, "g", self._sample_nutrition(), [])
        results = self.db.list_products(search_term="شوكولاتة")
        self.assertEqual(len(results), 1)
        results_none = self.db.list_products(search_term="غير موجود إطلاقًا")
        self.assertEqual(len(results_none), 0)


if __name__ == "__main__":
    unittest.main()
