@echo off
title FoodHealth

call conda activate foodhealth

cd /d "D:\AI\Code\نظام ذكي لتحليل المنتجات الغذائية وتقييم ملاءمتها الصحية باستخدام الذكاء الاصطناعي\foodhealth"

start "FoodHealth Flask" cmd /k "python app.py"

timeout /t 5 /nobreak >nul

start "FoodHealth Cloudflare" cmd /k ""C:\Program Files (x86)\cloudflared\cloudflared.exe" tunnel --url http://localhost:5000"

echo.
echo ==========================================
echo FoodHealth is starting...
echo ==========================================
echo.
pause