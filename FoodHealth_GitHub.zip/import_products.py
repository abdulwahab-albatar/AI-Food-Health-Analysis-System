import json
from database import db_helper
from ai.preprocessing import validate_product_input


JSON_FILE = "data/products.json"


def main():
    print("=" * 60)
    print("Importing products from products.json")
    print("=" * 60)

    # إنشاء جداول قاعدة البيانات إذا لم تكن موجودة
    db_helper.init_db()

    # قراءة ملف المنتجات
    with open(JSON_FILE, "r", encoding="utf-8") as f:
        products = json.load(f)

    print(f"Found {len(products)} products in JSON file.")
    print()

    imported = 0
    skipped = 0

    for index, product in enumerate(products, start=1):
        try:
            # التحقق وتنظيف البيانات
            cleaned = validate_product_input(product)

            # إضافة المنتج إلى قاعدة البيانات
            product_id = db_helper.create_product(
                barcode=cleaned["barcode"],
                product_name=cleaned["product_name"],
                manufacturer=cleaned["manufacturer"],
                category=cleaned["category"],
                serving_size=cleaned["serving_size"],
                unit=cleaned["unit"],
                nutrition=cleaned["nutrition"],
                ingredients=cleaned["ingredients"],
            )

            imported += 1
            print(
                f"[{index:02d}/{len(products)}] "
                f"OK - {cleaned['product_name']} "
                f"(ID: {product_id})"
            )

        except ValueError as e:
            skipped += 1
            print(
                f"[{index:02d}/{len(products)}] "
                f"SKIPPED - {product.get('product_name', 'Unknown')}: {e}"
            )

        except Exception as e:
            skipped += 1
            print(
                f"[{index:02d}/{len(products)}] "
                f"ERROR - {product.get('product_name', 'Unknown')}: {e}"
            )

    print()
    print("=" * 60)
    print("IMPORT FINISHED")
    print("=" * 60)
    print(f"Products in JSON : {len(products)}")
    print(f"Imported         : {imported}")
    print(f"Skipped/Errors   : {skipped}")
    print("=" * 60)


if __name__ == "__main__":
    main()