# config.py
"""
إعدادات المشروع المركزية.
كل القيم الثابتة (Thresholds، مسارات، إعدادات) توضع هنا حتى لا تكون
مبعثرة داخل الكود (Hard-Coded) بشكل غير منظم.
"""

import os

# ---------------------------------------------------------------------------
# المسارات
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# مكان قاعدة البيانات. عند التشغيل كـ EXE يجب ألا تكون في مسار مؤقت
# يُحذف عند إغلاق البرنامج، لذلك نستخدم مجلد بيانات خاص بالمستخدم.
def get_app_data_dir():
    """يحدد مجلد بيانات ثابت للتطبيق (مناسب أيضًا عند التشغيل كـ EXE)."""
    if os.environ.get("FOODHEALTH_PORTABLE") == "1":
        # وضع Portable: البيانات بجانب الملف التنفيذي
        data_dir = os.path.join(BASE_DIR, "data")
    else:
        home = os.path.expanduser("~")
        data_dir = os.path.join(home, "FoodHealthApp", "data")
    os.makedirs(data_dir, exist_ok=True)
    return data_dir

DATABASE_DIR = os.path.join(BASE_DIR, "data")
DATABASE_PATH = os.path.join(DATABASE_DIR, "food_health.db")
BACKUP_DIR = os.path.join(DATABASE_DIR, "backups")

MODEL_PATH = os.path.join(BASE_DIR, "models", "model.pkl")
DATASET_PATH = os.path.join(BASE_DIR, "data", "dataset.csv")

# ---------------------------------------------------------------------------
# إعدادات Flask
# ---------------------------------------------------------------------------
SECRET_KEY = "dev-secret-key-change-in-production"
DEBUG = True

# ============================================================
# Flask Server
# ============================================================

HOST = os.environ.get("FOODHEALTH_HOST", "0.0.0.0")
PORT = int(os.environ.get("FOODHEALTH_PORT", "5000"))


# ============================================================
# Cloud Synchronization
# ============================================================

# في مرحلة الاختبار المحلي نتركه فارغاً.
#
# بعد رفع المشروع على الإنترنت سيكون مثلاً:
#
# https://your-domain.com
#
SYNC_SERVER_URL = os.environ.get(
    "FOODHEALTH_SYNC_SERVER_URL",
    ""
)

SYNC_ENABLED = os.environ.get(
    "FOODHEALTH_SYNC_ENABLED",
    "1"
) == "1"

SYNC_TIMEOUT = int(
    os.environ.get(
        "FOODHEALTH_SYNC_TIMEOUT",
        "15"
    )
)

SYNC_ON_STARTUP = (
    os.environ.get(
        "FOODHEALTH_SYNC_ON_STARTUP",
        "1"
    ) == "1"
)

# ---------------------------------------------------------------------------
# عتبات القواعد (Rule-Based Thresholds) — لكل 100 غرام / 100 مل
# هذه القيم قابلة للتعديل من مكان واحد فقط (وليست موزعة داخل الكود)
# مصدرها: إرشادات عامة تعليمية مبسّطة (WHO / FDA - Educational simplification)
# ---------------------------------------------------------------------------
THRESHOLDS = {
    "sugar_high": 22.5,          # غرام / 100غ  -> مرتفع
    "sugar_medium": 5.0,
    "sodium_high": 600.0,        # ملغم / 100غ
    "sodium_medium": 120.0,
    "saturated_fat_high": 5.0,   # غرام / 100غ
    "saturated_fat_medium": 1.5,
    "total_fat_high": 17.5,
    "total_fat_medium": 3.0,
    "fiber_low": 3.0,
    "fiber_good": 6.0,
    "caffeine_high": 150.0,      # ملغم / حصة
    "preservatives_high": 3,     # عدد المواد الحافظة
}

# نقاط الخطر (Risk Score) لكل قاعدة يتم تفعيلها
RISK_POINTS = {
    "sugar_high": 3,
    "sugar_medium": 1,
    "sodium_high": 3,
    "sodium_medium": 1,
    "saturated_fat_high": 3,
    "saturated_fat_medium": 1,
    "total_fat_high": 2,
    "fiber_low": 1,
    "caffeine_high": 2,
    "preservatives_high": 1,
}

# حدود تصنيف النتيجة النهائية إلى SAFE / CAUTION / UNSAFE
CLASSIFICATION_BOUNDARIES = {
    "safe_max": 2,       # score <= 2  -> SAFE
    "caution_max": 5,    # 2 < score <= 5 -> CAUTION
    # score > 5 -> UNSAFE
}

# ============================================================
# Supabase Configuration
# ============================================================
from dotenv import load_dotenv

load_dotenv(os.path.join(BASE_DIR, '.env'))

SUPABASE_URL = os.environ.get('SUPABASE_URL', '').strip()
SUPABASE_KEY = os.environ.get('SUPABASE_KEY', '').strip()
SUPABASE_ENABLED = bool(SUPABASE_URL and SUPABASE_KEY)
