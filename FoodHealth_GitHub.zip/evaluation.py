# routes/evaluation.py
"""
Routes الخاصة بالتقييم الصحي (استدعاء AI) ولوحة الإحصائيات (Dashboard).

هذا هو المكان الذي يظهر فيه Data Flow الكامل:
    Database -> Preprocessing -> AI Algorithm -> Database -> HTML
"""

from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash

from database import db_helper
from ai.preprocessing import normalize_per_100
from ai.rules_engine import evaluate_product

evaluation_bp = Blueprint("evaluation", __name__)


@evaluation_bp.route("/evaluate/<int:product_id>", methods=["GET", "POST"])
def evaluate(product_id):
    data = db_helper.get_product_by_id(product_id)
    if not data:
        flash("المنتج غير موجود.", "error")
        return redirect(url_for("products.products_page"))

    health_condition = request.values.get("health_condition", "general")

    # 1) Database -> Retrieve
    nutrition = data["nutrition"]
    serving_size = data["product"]["serving_size"]

    # 2) Preprocessing -> Normalize (لكل 100غ حتى تتوافق مع العتبات)
    normalized = normalize_per_100(nutrition, serving_size, data["product"]["unit"])

    # 3) AI Algorithm -> Rule-Based Evaluation
    result = evaluate_product(normalized, data["ingredients"], health_condition)

    # 4) Database -> Save evaluation result
    db_helper.save_evaluation(
        product_id=product_id,
        health_condition=health_condition,
        score=result["score"],
        risk_level=result["risk_level"],
        recommendation=result["recommendation"],
        detected_risks_json=result["detected_risks_json"],
    )

    return render_template(
        "evaluation.html",
        product=data["product"],
        nutrition=nutrition,
        normalized=normalized,
        result=result,
        health_condition=health_condition,
    )


@evaluation_bp.route("/dashboard")
def dashboard():
    stats = db_helper.get_statistics()
    db_analysis = db_helper.get_db_analysis()
    return render_template("dashboard.html", stats=stats, db_analysis=db_analysis)


@evaluation_bp.route("/api/backup", methods=["POST"])
def backup():
    try:
        path = db_helper.backup_database()
        return jsonify({"success": True, "path": path})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
