# FoodHealth
## Intelligent Food Product Analysis and Health Suitability Assessment System

### 1. Project Overview

FoodHealth is an intelligent software project designed to analyze food products and assess their health suitability using food product data, nutritional information, ingredients, and artificial intelligence techniques where implemented.

The system aims to help users explore food products, review their available nutritional information, and understand the health assessment provided by the application.

The project includes a source-code application, a desktop application package, a final project report, screenshots documenting the running system, and a Python dependency file.

**Important:** The system's assessments are intended for informational purposes and should not replace professional medical or nutritional advice.

---

### 2. Project Files and Folders

The project contains the following main files and folders.

#### A. `app.py` — Main Application

This file serves as the main application entry point when configured to run the Flask application.

It initializes the application and connects the required routes and services.

**How to open it:**
1. Open the project directory.
2. Locate `app.py`.
3. Open it using Visual Studio Code or another Python code editor.
4. Review or modify the source code as needed.

#### B. `FoodHealth_Final_Project_Report.docx` — Final Project Report

This document contains the project's academic report.

It can be used to review the project description, objectives, design, implementation, and results documented in the report.

**How to open it:**
1. Locate `FoodHealth_Final_Project_Report.docx`.
2. Double-click the file.
3. Open it with Microsoft Word or another compatible DOCX application.

#### C. `FoodHealth_Desktop_Application` — Desktop Application

This folder contains the packaged desktop version of FoodHealth.

It is intended to provide a convenient way to run the application on compatible Windows computers.

**How to run it:**
1. Open the `FoodHealth_Desktop_Application` folder.
2. Locate `FoodHealth.exe`, if present.
3. Double-click the executable.
4. Wait for the application interface to appear.

The application may require additional bundled files, network access, or external service configuration, depending on how it was packaged.

#### D. `Running_System_Screenshots` — Application Screenshots

This folder contains screenshots documenting the application interfaces while the system is running.

These images can be used for project documentation, demonstrations, presentations, and academic discussions.

**How to view the screenshots:**
1. Open `Running_System_Screenshots`.
2. Select an image.
3. Double-click it to open it in the default image viewer.

#### E. `requirements.txt` — Python Dependencies

This file lists Python packages and their versions when generated from the project's Python environment.

It helps developers recreate the software environment required to run or modify the source code.

The development environment used for this project runs Python 3.9.25.

**How to view the file:**
1. Locate `requirements.txt`.
2. Open it with Notepad or Visual Studio Code.
3. Review the package names and version numbers.

---

### 3. Running the Source Code

To run the application from its Python source code:

1. Install a compatible Python environment.
2. Open Anaconda Prompt.
3. Activate the appropriate Conda environment.
4. Navigate to the project directory.
5. Install the required dependencies.
6. Configure the necessary environment variables and external services.
7. Start the application.

Example commands:

```bash
conda activate foodhealth
```

Navigate to the project directory:

```bat
cd /d "D:\AI\Code\نظام ذكي لتحليل المنتجات الغذائية وتقييم ملاءمتها الصحية باستخدام الذكاء الاصطناعي\foodhealth"
```

Install dependencies:

```bash
python -m pip install -r requirements.txt
```

Run the application:

```bash
python app.py
```

These commands assume that the Conda environment already exists and that `app.py` is the correct entry point.

The project may require additional configuration, including database credentials and environment variables, before it can run successfully.

---

### 4. Running the Desktop Application

To run the packaged desktop application on a Windows computer:

1. Copy the `FoodHealth_Desktop_Application` folder to the target computer.
2. Open the folder.
3. Locate `FoodHealth.exe`.
4. Double-click the executable.
5. Ensure that any required external services are available.

If the application connects to a cloud database, an internet connection and valid configuration may be necessary.

A properly packaged PyInstaller application can generally run without a separate Python installation, provided that all required dependencies and supporting files are included.

---

### 5. Opening and Modifying the Source Code

Developers can use Visual Studio Code or another compatible Python editor.

Recommended procedure:

1. Open the main project directory in the editor.
2. Open `app.py` to review the application entry point.
3. Explore the `routes`, `services`, and `utils` directories if present.
4. Review the configuration and database-related files.
5. Make the required changes.
6. Save the modified files.
7. Run and test the application.

Always create a backup before making significant changes.

Do not publish database credentials, API keys, or other secrets contained in environment configuration files.

---

### 6. Python Environment and Dependencies

The project's development environment uses Python 3.9.25.

The `requirements.txt` file can be used to install the listed packages:

```bash
python -m pip install -r requirements.txt
```

For a new computer, create or configure a compatible Python environment before installing the dependencies.

The dependency file does not include the project's source code, product dataset, database contents, or secret configuration values.

---

### 7. Project Demonstration and Academic Presentation

For an academic demonstration, the following sequence is recommended:

1. Present `FoodHealth_Final_Project_Report.docx` to explain the project objectives and design.
2. Open `Running_System_Screenshots` to show the documented interfaces.
3. Run the desktop application to demonstrate its available features.
4. Review `app.py` and the relevant source-code modules.
5. Present `requirements.txt` to document the Python dependencies.
6. Explain the dataset, preprocessing, algorithms, training, testing, and evaluation based on the actual implementation.

Algorithm names, model performance, and dataset sources should be reported only when supported by the project's source code and experimental records.

---

### 8. Important Notes

- Keep backup copies of the source code and project data.
- Protect all database credentials and API keys.
- Verify the required configuration before running the application on another computer.
- Keep the source code separate from the packaged desktop application.
- Review the nutritional data and assessment logic before relying on the system's results.
- The application provides informational support and does not replace professional medical advice.

---

### 9. Conclusion

FoodHealth is a software project focused on food product analysis and health suitability assessment.

Its source code supports development and maintenance, the desktop package provides a convenient execution option, the final report documents the academic work, the screenshots demonstrate the running interfaces, and the dependency file helps developers prepare the Python environment.

Together, these resources support project operation, documentation, demonstration, and future development.