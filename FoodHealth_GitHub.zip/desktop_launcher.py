# desktop_launcher.py
"""
نقطة دخول مخصّصة لتحويل المشروع إلى EXE.

لماذا ملف منفصل عن app.py؟
    لأن PyInstaller يبني EXE واحدًا يشغّل سكربتًا واحدًا مباشرة دون أن
    يستقبل معاملات سطر أوامر (--desktop) بسهولة. لذلك هذا الملف بسيط
    ومباشر: يستدعي وضع سطح المكتب دائمًا.

هذا هو الملف الذي يُمرَّر إلى PyInstaller (وليس app.py) — انظر build_exe.bat.
"""

from app import run_desktop

if __name__ == "__main__":
    run_desktop()
