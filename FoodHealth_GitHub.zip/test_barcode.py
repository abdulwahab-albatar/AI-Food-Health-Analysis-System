# tests/test_barcode.py
"""اختبارات الباركود: Valid, Invalid, ومحاكاة فشل الصورة."""

import os
import sys
import unittest

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai.preprocessing import validate_barcode, ValidationError
from utils.barcode_utils import detect_barcode_from_image


class TestBarcodeValidation(unittest.TestCase):
    def test_valid_ean8(self):
        self.assertEqual(validate_barcode("12345678"), "12345678")

    def test_valid_ean13(self):
        self.assertEqual(validate_barcode("1234567890123"), "1234567890123")

    def test_too_short_fails(self):
        with self.assertRaises(ValidationError):
            validate_barcode("123")

    def test_letters_fail(self):
        with self.assertRaises(ValidationError):
            validate_barcode("1234ABCD")


class TestBarcodeCameraDetection(unittest.TestCase):
    def test_invalid_base64_returns_error_not_exception(self):
        """التقاط صورة فاسدة يجب أن يُعيد خطأ واضحًا وليس Exception غير معالج."""
        result = detect_barcode_from_image("not-a-valid-base64-image!!")
        self.assertFalse(result["found"])
        self.assertIsNotNone(result["error"])

    def test_empty_image_field(self):
        result = detect_barcode_from_image("")
        self.assertFalse(result["found"])


if __name__ == "__main__":
    unittest.main()
