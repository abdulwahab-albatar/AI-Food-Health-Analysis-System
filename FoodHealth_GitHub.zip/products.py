# routes/products.py
"""
Product routes.

Primary data source:
    Supabase

Fallback:
    SQLite

The existing database layer is kept intact so that
local/offline operation and existing evaluation features
continue to work.
"""

from flask import (
    Blueprint,
    render_template,
    request,
    jsonify,
    redirect,
    url_for,
    flash,
)

from database import db_helper
from services import supabase_service
from ai.preprocessing import validate_product_input, ValidationError


products_bp = Blueprint("products", __name__)


# ============================================================
# Helpers
# ============================================================

def _supabase_enabled():
    """Return True when Supabase is configured and reachable."""
    try:
        return supabase_service.is_available()
    except Exception:
        return False


def _get_supabase_products(search_term=None, limit=200):
    """
    Get products from Supabase.

    Returns an empty list when Supabase is unavailable.
    """
    try:
        products = supabase_service.get_products()

        if not products:
            return []

        if search_term:
            search = search_term.lower()

            products = [
                product
                for product in products
                if search in str(product.get("product_name", "")).lower()
                or search in str(product.get("barcode", "")).lower()
                or search in str(product.get("manufacturer", "")).lower()
            ]

        return products[:limit]

    except Exception:
        return []


def _get_supabase_product_full(product_id):
    """
    Get a complete product from Supabase.

    Combines:
        products
        nutrition
        ingredients
    """

    try:
        client = supabase_service.get_client()

        if client is None:
            return None

        product_response = (
            client
            .table("products")
            .select("*")
            .eq("product_id", product_id)
            .limit(1)
            .execute()
        )

        if not product_response.data:
            return None

        product = product_response.data[0]

        nutrition_response = (
            client
            .table("nutrition")
            .select("*")
            .eq("product_id", product_id)
            .limit(1)
            .execute()
        )

        nutrition = (
            nutrition_response.data[0]
            if nutrition_response.data
            else {}
        )

        ingredients_response = (
            client
            .table("ingredients")
            .select("*")
            .eq("product_id", product_id)
            .order("ingredient_id")
            .execute()
        )

        ingredients = ingredients_response.data or []

        return {
            "product": product,
            "nutrition": nutrition,
            "ingredients": ingredients,
        }

    except Exception:
        return None


def _get_supabase_evaluations(product_id):
    """Get evaluations for a product from Supabase."""

    try:
        client = supabase_service.get_client()

        if client is None:
            return []

        response = (
            client
            .table("evaluations")
            .select("*")
            .eq("product_id", product_id)
            .order("evaluation_date", desc=True)
            .execute()
        )

        return response.data or []

    except Exception:
        return []


# ============================================================
# Product List
# ============================================================

@products_bp.route("/products")
def products_page():
    """
    Display products.

    Supabase is the primary source.
    SQLite is used as fallback.
    """

    search = request.args.get("q", "").strip()

    products = _get_supabase_products(
        search_term=search or None,
        limit=200,
    )

    source = "supabase"

    if not products and not search:
        products = db_helper.list_products(
            search_term=None,
            limit=200,
        )
        source = "sqlite"

    elif not products and search:
        products = db_helper.list_products(
            search_term=search,
            limit=200,
        )
        source = "sqlite"

    return render_template(
        "products.html",
        products=products,
        search=search,
        data_source=source,
    )


# ============================================================
# Add Product
# ============================================================

@products_bp.route("/products/add", methods=["GET", "POST"])
def add_product():

    if request.method == "GET":
        return render_template(
            "add_product.html",
            product=None,
            ingredients_text="",
        )

    try:

        cleaned = validate_product_input(
            request.form.to_dict()
        )

        product_id = db_helper.create_product(
            barcode=cleaned["barcode"],
            product_name=cleaned["product_name"],
            manufacturer=cleaned["manufacturer"],
            category=cleaned["category"],
            serving_size=cleaned["serving_size"],
            unit=cleaned["unit"],
            nutrition=cleaned["nutrition"],
            ingredients=cleaned["ingredients"],
        )

        flash(
            "تمت إضافة المنتج بنجاح.",
            "success",
        )

        return redirect(
            url_for(
                "products.product_details",
                product_id=product_id,
            )
        )

    except ValidationError as e:

        flash(str(e), "error")

        return render_template(
            "add_product.html",
            product=request.form,
            ingredients_text=request.form.get(
                "ingredients",
                "",
            ),
        )

    except ValueError as e:

        flash(str(e), "error")

        return render_template(
            "add_product.html",
            product=request.form,
            ingredients_text=request.form.get(
                "ingredients",
                "",
            ),
        )


# ============================================================
# Product Details
# ============================================================

@products_bp.route("/products/<int:product_id>")
def product_details(product_id):

    # --------------------------------------------------------
    # Primary: Supabase
    # --------------------------------------------------------

    data = _get_supabase_product_full(product_id)

    if data:

        evaluations = _get_supabase_evaluations(
            product_id
        )

        return render_template(
            "product_details.html",
            data=data,
            evaluations=evaluations,
        )

    # --------------------------------------------------------
    # Fallback: SQLite
    # --------------------------------------------------------

    data = db_helper.get_product_by_id(
        product_id
    )

    if not data:

        flash(
            "المنتج غير موجود.",
            "error",
        )

        return redirect(
            url_for(
                "products.products_page"
            )
        )

    evaluations = db_helper.get_evaluations_for_product(
        product_id
    )

    return render_template(
        "product_details.html",
        data=data,
        evaluations=evaluations,
    )


# ============================================================
# Edit Product
# ============================================================

@products_bp.route(
    "/products/<int:product_id>/edit",
    methods=["GET", "POST"],
)
def edit_product(product_id):

    # Editing remains local for now.
    # This preserves the existing CRUD implementation.

    data = db_helper.get_product_by_id(
        product_id
    )

    if not data:

        flash(
            "المنتج غير موجود.",
            "error",
        )

        return redirect(
            url_for(
                "products.products_page"
            )
        )

    if request.method == "GET":

        ingredients_text = ", ".join(
            i["ingredient_name"]
            for i in data["ingredients"]
        )

        return render_template(
            "add_product.html",
            product=data["product"] | data["nutrition"],
            ingredients_text=ingredients_text,
            editing=True,
            product_id=product_id,
        )

    try:

        form_data = request.form.to_dict()

        # Barcode cannot be changed.
        form_data["barcode"] = data["product"]["barcode"]

        cleaned = validate_product_input(
            form_data
        )

        db_helper.update_product(
            product_id=product_id,
            product_name=cleaned["product_name"],
            manufacturer=cleaned["manufacturer"],
            category=cleaned["category"],
            serving_size=cleaned["serving_size"],
            unit=cleaned["unit"],
            nutrition=cleaned["nutrition"],
            ingredients=cleaned["ingredients"],
        )

        flash(
            "تم تحديث المنتج بنجاح.",
            "success",
        )

        return redirect(
            url_for(
                "products.product_details",
                product_id=product_id,
            )
        )

    except ValidationError as e:

        flash(
            str(e),
            "error",
        )

        return redirect(
            url_for(
                "products.edit_product",
                product_id=product_id,
            )
        )


# ============================================================
# Delete Product
# ============================================================

@products_bp.route(
    "/products/<int:product_id>/delete",
    methods=["POST"],
)
def delete_product(product_id):

    db_helper.delete_product(
        product_id
    )

    flash(
        "تم حذف المنتج.",
        "success",
    )

    return redirect(
        url_for(
            "products.products_page"
        )
    )


# ============================================================
# AJAX Product Search
# ============================================================

@products_bp.route(
    "/api/products/search"
)
def api_search_products():

    search = request.args.get(
        "q",
        "",
    ).strip()

    products = _get_supabase_products(
        search_term=search or None,
        limit=50,
    )

    source = "supabase"

    if not products:

        products = db_helper.list_products(
            search_term=search or None,
            limit=50,
        )

        source = "sqlite"

    return jsonify({
        "products": products,
        "source": source,
    })

